//
// Generated file, do not edit! Created by nedtool 4.6 from src/node/application/aroundApproachApp/AroundDataPacket.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "AroundDataPacket_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

EXECUTE_ON_STARTUP(
    cEnum *e = cEnum::find("AroundDataPacket_type");
    if (!e) enums.getInstance()->add(e = new cEnum("AroundDataPacket_type"));
    e->insert(AROUND_DATA_BACKGROUND, "AROUND_DATA_BACKGROUND");
    e->insert(AROUND_DATA_SRC2SNK, "AROUND_DATA_SRC2SNK");
    e->insert(AROUND_DATA_FLOW, "AROUND_DATA_FLOW");
);

Register_Class(AroundDataPacket);

AroundDataPacket::AroundDataPacket(const char *name, int kind) : ::ApplicationPacket(name,kind)
{
    this->AroundDataPacketType_var = 0;
    this->SourceNode_var = 0;
    this->DestinationNode_var = 0;
    this->Data_var = 0;
    this->SeqNumber_var = 0;
}

AroundDataPacket::AroundDataPacket(const AroundDataPacket& other) : ::ApplicationPacket(other)
{
    copy(other);
}

AroundDataPacket::~AroundDataPacket()
{
}

AroundDataPacket& AroundDataPacket::operator=(const AroundDataPacket& other)
{
    if (this==&other) return *this;
    ::ApplicationPacket::operator=(other);
    copy(other);
    return *this;
}

void AroundDataPacket::copy(const AroundDataPacket& other)
{
    this->AroundDataPacketType_var = other.AroundDataPacketType_var;
    this->SourceNode_var = other.SourceNode_var;
    this->DestinationNode_var = other.DestinationNode_var;
    this->Data_var = other.Data_var;
    this->SeqNumber_var = other.SeqNumber_var;
}

void AroundDataPacket::parsimPack(cCommBuffer *b)
{
    ::ApplicationPacket::parsimPack(b);
    doPacking(b,this->AroundDataPacketType_var);
    doPacking(b,this->SourceNode_var);
    doPacking(b,this->DestinationNode_var);
    doPacking(b,this->Data_var);
    doPacking(b,this->SeqNumber_var);
}

void AroundDataPacket::parsimUnpack(cCommBuffer *b)
{
    ::ApplicationPacket::parsimUnpack(b);
    doUnpacking(b,this->AroundDataPacketType_var);
    doUnpacking(b,this->SourceNode_var);
    doUnpacking(b,this->DestinationNode_var);
    doUnpacking(b,this->Data_var);
    doUnpacking(b,this->SeqNumber_var);
}

int AroundDataPacket::getAroundDataPacketType() const
{
    return AroundDataPacketType_var;
}

void AroundDataPacket::setAroundDataPacketType(int AroundDataPacketType)
{
    this->AroundDataPacketType_var = AroundDataPacketType;
}

int AroundDataPacket::getSourceNode() const
{
    return SourceNode_var;
}

void AroundDataPacket::setSourceNode(int SourceNode)
{
    this->SourceNode_var = SourceNode;
}

int AroundDataPacket::getDestinationNode() const
{
    return DestinationNode_var;
}

void AroundDataPacket::setDestinationNode(int DestinationNode)
{
    this->DestinationNode_var = DestinationNode;
}

double AroundDataPacket::getData() const
{
    return Data_var;
}

void AroundDataPacket::setData(double Data)
{
    this->Data_var = Data;
}

int AroundDataPacket::getSeqNumber() const
{
    return SeqNumber_var;
}

void AroundDataPacket::setSeqNumber(int SeqNumber)
{
    this->SeqNumber_var = SeqNumber;
}

class AroundDataPacketDescriptor : public cClassDescriptor
{
  public:
    AroundDataPacketDescriptor();
    virtual ~AroundDataPacketDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(AroundDataPacketDescriptor);

AroundDataPacketDescriptor::AroundDataPacketDescriptor() : cClassDescriptor("AroundDataPacket", "ApplicationPacket")
{
}

AroundDataPacketDescriptor::~AroundDataPacketDescriptor()
{
}

bool AroundDataPacketDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<AroundDataPacket *>(obj)!=NULL;
}

const char *AroundDataPacketDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int AroundDataPacketDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 5+basedesc->getFieldCount(object) : 5;
}

unsigned int AroundDataPacketDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<5) ? fieldTypeFlags[field] : 0;
}

const char *AroundDataPacketDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "AroundDataPacketType",
        "SourceNode",
        "DestinationNode",
        "Data",
        "SeqNumber",
    };
    return (field>=0 && field<5) ? fieldNames[field] : NULL;
}

int AroundDataPacketDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='A' && strcmp(fieldName, "AroundDataPacketType")==0) return base+0;
    if (fieldName[0]=='S' && strcmp(fieldName, "SourceNode")==0) return base+1;
    if (fieldName[0]=='D' && strcmp(fieldName, "DestinationNode")==0) return base+2;
    if (fieldName[0]=='D' && strcmp(fieldName, "Data")==0) return base+3;
    if (fieldName[0]=='S' && strcmp(fieldName, "SeqNumber")==0) return base+4;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *AroundDataPacketDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "int",
        "int",
        "double",
        "int",
    };
    return (field>=0 && field<5) ? fieldTypeStrings[field] : NULL;
}

const char *AroundDataPacketDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 0:
            if (!strcmp(propertyname,"enum")) return "AroundDataPacket_type";
            return NULL;
        default: return NULL;
    }
}

int AroundDataPacketDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    AroundDataPacket *pp = (AroundDataPacket *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string AroundDataPacketDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    AroundDataPacket *pp = (AroundDataPacket *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getAroundDataPacketType());
        case 1: return long2string(pp->getSourceNode());
        case 2: return long2string(pp->getDestinationNode());
        case 3: return double2string(pp->getData());
        case 4: return long2string(pp->getSeqNumber());
        default: return "";
    }
}

bool AroundDataPacketDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    AroundDataPacket *pp = (AroundDataPacket *)object; (void)pp;
    switch (field) {
        case 0: pp->setAroundDataPacketType(string2long(value)); return true;
        case 1: pp->setSourceNode(string2long(value)); return true;
        case 2: pp->setDestinationNode(string2long(value)); return true;
        case 3: pp->setData(string2double(value)); return true;
        case 4: pp->setSeqNumber(string2long(value)); return true;
        default: return false;
    }
}

const char *AroundDataPacketDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    };
}

void *AroundDataPacketDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    AroundDataPacket *pp = (AroundDataPacket *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}


