//****************************************************************************
//*  Copyright (c) Faculty of Engineering, University of Porto, Portugal     *
//*  All rights reserved                                                     *
//*                                                                          *
//*  Module:   ARounD Approach for Castalia Simulator                        *
//*  File: AroundApproachApp.cc                                              *
//*  Date: 2015-03-05                                                        *
//*  Version:  0.1                                                           *
//*  Author(s): Erico Leão <ericoleao@gmail.com>                             *
//****************************************************************************/

#include "AroundApproachApp.h"
#include "Basic802154AroundControl_m.h"

Define_Module(AroundApproachApp);

void AroundApproachApp::startup()
{
    // Para implementação do journal de análise protocolar, packet_spacing é definido para cada node, ou seja
    // cada node tem seu próprio packet rate. Assim, as definições abaixo tem que ser feitas individualmente para cada node
    
    // ---- IMPLEMENTACAO PADRAO: pegando data-rate do arquivo de inicializacao-----
    packet_rate = par("packet_rate");  //Taxa de geração de pacotes (pkts/sec)
    packet_spacing = packet_rate > 0 ? 1 / float (packet_rate) : -1;  // Período entre o envio de pacotes (pkts/sec)
    // ---- IMPLEMENTACAO PADRAO: pegando data-rate do arquivo de inicializacao-----
    
    
    
    // ---- IMPLEMENTACAO ARTIGO DA ANALISE PROTOCOLAR: data-rate com base na posicao no ambiente
//    VirtualMobilityManager *nodeMobilityModule = check_and_cast<VirtualMobilityManager*>(getParentModule()->getSubmodule("MobilityManager"));
//    double xCH = nodeMobilityModule->getLocation().x;
//    double yCH = nodeMobilityModule->getLocation().y;
//    //trace() << "MINHAS COORDENADAS: X = " << xCH << " e Y = " << yCH;  //debug
//    
//    if(xCH > yCH){ //está no triangulo inferior do ambiente
//        packet_rate = 0.01;
//        packet_spacing = 1 / 0.01;
//        trace() << "TRIANGULO " << selfAddress.c_str() << " 0 - datarate " << packet_spacing;   //debug
//    } else { //está no triangulo superior do ambiente
//        packet_rate = 0.05;
//        packet_spacing = 1 / 0.05;
//        trace() << "TRIANGULO " << selfAddress.c_str() << " 1 - datarate " << packet_spacing;   //debug
//    }
    // ---- IMPLEMENTACAO ARTIGO DA ANALISE PROTOCOLAR: data-rate com base na posicao no ambiente
    
    
    // Endereço do dispositivo sink
	sinkAddress = par("sink").stringValue();
    sinkId = atoi(sinkAddress.c_str());
	// Atraso para início da geração de dados
    startupDelay = par("startupDelay");
    // Limite de atraso para a aplicação
    // Valor 0 é infinito. Descarta após ultrapassar esse limite.
	delayLimit = par("delayLimit");
    
	

    // Configurando uma comunicação SOURCE TO SINK
    s2sSink = par("source2sink").stringValue();
    s2sSinkId = atoi(s2sSink.c_str());
    s2sStartupDelay = par("s2sStartupDelay");
    s2sDuration = par("s2sDuration");
    s2sRatePacket = par("s2sRatePacket");
    
    if(s2sSinkId != -1){  //defini s2sSinkId como default -1
        if((s2sStartupDelay == 0.0) || (s2sDuration == 0.0) || (s2sRatePacket == 0.0)){
            trace() << "Not defined the SOURCE-2-SINK Communcation parameters";
            opp_error("Not defined the SOURCE-2-SINK Communcation parameters");
        }
        setTimer(SEND_SRC2SINK_PACKET, s2sStartupDelay);  // + (1 / float (s2sRatePacket)));
        //setTimer(STOP_SRC2SINK_PACKET, s2sStartupDelay + (float (s2sDuration)));
    }
    
    // Configurando uma comunicação AROUND
    // Configuração parte do nó root, no qual irá enviar pacote de controle pro MAC para decisão do menor caminho
    if ( atoi(selfAddress.c_str()) == 0){
        aroundFlowConfiguration();
    }
    
    
    //Node irá gerar dados de background (default é true)
    dataGen = par("dataGen");
    
    
    // Números de sequências dos pacotes de aplicação
    dataSN = 0;     // Tráfego de base
    src2snkSN = 0;  // Tráfego source/sink
    aroundSN = 0; // Tráfego Around source/sink
    sentPacketCount = 0; //Contador para pacotes de background enviados
    sentPacketMAX = par("sentPacketMAX"); //Quantidade de pacotes de background máximo para os nós
    
	
    // Número de nós da rede - PAra estatísticas
	numNodes = getParentModule()->getParentModule()->par("numNodes");
	
    // limpa as estruturas
    packetsSent = 0;
	packetsReceived.clear();
    s2sPacketsSent = 0;
    s2sPacketsReceived.clear();
    aroundPacketsSent = 0;
    aroundPacketsReceived.clear();
    
    //contPKT = 0; //
    
    //Estatísticas - Castalia Results
    declareOutput("Generated Background Packets");
    declareOutput("BUFFER CHEIO");
    
}

void AroundApproachApp::fromNetworkLayer(ApplicationPacket * rcvPacket, const char *source, double rssi, double lqi){
/////	trace () << "ENTREI NO APP FROM NETWORK!"; //around - debug
    
    int sequenceNumber = rcvPacket->getSequenceNumber();
	int sourceId = atoi(source);
    
    AroundDataPacket *aroundPacket = check_and_cast<AroundDataPacket*>(rcvPacket);
    
/////    trace() << "PACOTE RECEBIDO DE " << aroundPacket->getSourceNode(); //around - debug
    
    switch (aroundPacket->getAroundDataPacketType()) {
        
        //Pacote de Background
        case AROUND_DATA_BACKGROUND:
/////            trace() << "RECEBI PACOTE DE TRAFEGO DE BASE DE " << aroundPacket->getSourceNode() << " SeqNum " << aroundPacket->getSeqNumber(); //around - debug
            //Appinfos()<< "BACKGROUND DATA: RECEIVED BY " << SELF_NETWORK_ADDRESS << " FROM NODE " <<source<< " - NumSeq " << aroundPacket->getSeqNumber() << " - Delay: " << simTime() - rcvPacket->getCreationTime();
            packetsReceived[aroundPacket->getSourceNode()]++;
            
            //Usando o tipo sim_time estava gerando problemas em simulações grandes. Acredito que pela capacidade de armazenar grandes valores
            //averageDelay[aroundPacket->getSourceNode()] += (simTime() - rcvPacket->getCreationTime());
            
            // Assim, troquei pelas linhas abaixo, fazendo cast do sim_time para double. Aparentemente funcionou
            double packetTime;
            packetTime = (simTime().dbl() - rcvPacket->getCreationTime().dbl());
            averageDelay[aroundPacket->getSourceNode()] += packetTime;
            
            break;
        
        //Pacote SOURCE TO SINK
        case AROUND_DATA_SRC2SNK:
/////            trace() << "RECEBI PACOTE DE DADOS COM SOURCE " << aroundPacket->getSourceNode() << " SeqNum " << aroundPacket->getSeqNumber(); //around - debug
            //Appinfos()<< "SRC-TO-SNK DATA: RECEIVED BY " << SELF_NETWORK_ADDRESS << " FROM NODE " <<source<< " - NumSeq " << aroundPacket->getSeqNumber() << " - Delay: " << simTime() - rcvPacket->getCreationTime();
            s2sPacketsReceived[aroundPacket->getSourceNode()]++;
            
            //Usando o tipo sim_time estava gerando problemas em simulações grandes. Acredito que pela capacidade de armazenar grandes valores
            //s2sAverageDelay[aroundPacket->getSourceNode()] += (simTime() - rcvPacket->getCreationTime());
            
            // Assim, troquei pelas linhas abaixo, fazendo cast do sim_time para double. Aparentemente funcionou
            double s2spacketTime;
            s2spacketTime = (simTime().dbl() - rcvPacket->getCreationTime().dbl());
            s2sAverageDelay[aroundPacket->getSourceNode()] += s2spacketTime;
            
            
            
//            // ------- MECANISMO para pegar energia
//            contPKT++; //contando pacotes
//            
//            //defini 50000 pacotes máximo
//            if(contPKT == 1){
//                int k;
//                for(k = 0; k < 503; k++){
//                    //Pegando o ponteiro do nó atual
//                    AroundApproachApp *node = check_and_cast<AroundApproachApp*>(getParentModule()->getParentModule()->getSubmodule("node",k)->getSubmodule("Application"));
//                    trace() << "NODE " << k << " gastou " << node->resMgrModule->getSpentEnergy();
//                }
//            }
//            
//            // ------- FIM DO MECANISMO para pegar energia
            
            
            
            break;
            
        //Pacote SOURCE TO SINK
        case AROUND_DATA_FLOW:
/////            trace() << "RECEBI PACOTE AROUND COM SOURCE " << aroundPacket->getSourceNode() << " SeqNum " << aroundPacket->getSeqNumber(); //around - debug
            //Appinfos()<< "AROUND: RECEIVED BY " << SELF_NETWORK_ADDRESS << " FROM NODE " <<source<< " - NumSeq " << aroundPacket->getSeqNumber() << " - Delay: " << simTime() - rcvPacket->getCreationTime();
            aroundPacketsReceived[aroundPacket->getSourceNode()]++;
            
            //Usando o tipo sim_time estava gerando problemas em simulações grandes. Acredito que pela capacidade de armazenar grandes valores
            //aroundAverageDelay[aroundPacket->getSourceNode()] += (simTime() - rcvPacket->getCreationTime());
            
            // Assim, troquei pelas linhas abaixo, fazendo cast do sim_time para double. Aparentemente funcionou
            double aroundpacketTime;
            aroundpacketTime = (simTime().dbl() - rcvPacket->getCreationTime().dbl());
            aroundAverageDelay[aroundPacket->getSourceNode()] += aroundpacketTime;
            
            
            break;
    
    
    }
}

void AroundApproachApp::timerFiredCallback(int index)
{
	switch (index) {
		
        // Configuração de um fluxo around
        case AROUND_FLOW:{
            //vector <struct aroundconf>::const_iterator iter;
            vector <struct aroundconf>::iterator iter;
            iter = aroundFlows.begin();
            //trace() << "AROUND Configuration: FLOW (" << iter->src << " -> " << iter->dst << "); " << iter->packetrate << " pkts/sec and duration (sec) " <<  iter->duration;
            
            AroundControlMessage *cmd = new AroundControlMessage("Around Communication Configuration", MAC_CONTROL_COMMAND);
            cmd->setAroundControlMessageKind(SET_AROUND);
            around config;
            config.src = iter->src;
            config.dst = iter->dst;
            config.pktrate = iter->packetrate;
            config.duration = iter->duration;
            cmd->setConfig(config);
            toNetworkLayer(cmd);
            
            aroundFlows.erase(iter);
            if(aroundFlows.size() != 0){
                iter = aroundFlows.begin();
                setTimer(AROUND_FLOW, iter->starttime - getClock());
            }
            
            break;
        }
        
        // Enviar pacote de trafego background
        case SEND_PACKET:{
/////			trace() << "Sending packet #" << dataSN; //around - debug
			//Appinfos()<<"S "<<SELF_NETWORK_ADDRESS<<" "<<dataSN;
            //Appinfos()<< "BACKGROUND DATA: SENT BY " << SELF_NETWORK_ADDRESS << " - NumSeq " << dataSN;
            //Envia um pacote recem criado para a camada de rede
            // createGenericPacket tem os seguintes parâmetros: (double data, int sequenceNum, int size)
            // Se o tamanho não é fornecido, então ele é definido para constantDataPayload da aplicação
            // to NetworkLayer tem os seguintes parâmetros: (*msg) ou (*msg, const char *dstAddr)
			//toNetworkLayer(createGenericDataPacket(0, dataSN), sinkAddress.c_str());
            //toNetworkLayer(createGenericDataPacket(0, dataSN), "-1");
            
            // Criando o próprio pacote de aplicação
            AroundDataPacket *dataPkt = new AroundDataPacket("App Base Traffic Packet", APPLICATION_PACKET);
            dataPkt->setAroundDataPacketType(AROUND_DATA_BACKGROUND);
            dataPkt->setSourceNode(atoi(selfAddress.c_str()));
            dataPkt->setDestinationNode(-1);
            dataPkt->setData(0);
            dataPkt->setSeqNumber(dataSN);
            dataPkt->setByteLength(AROUND_DATA_BACKGROUND_SIZE);
            
            toNetworkLayer(dataPkt, "-1");
            
            // Coletar estatísticas para pacotes gerados!!
        	collectOutput("Generated Background Packets");
			packetsSent++;
			
            dataSN++;
			setTimer(SEND_PACKET, packet_spacing);
            
            sentPacketCount++;
            //Definindo aqui o timer para parar o envio com base na quantidade máxima de pacotes definida
            if(sentPacketCount == sentPacketMAX)
                setTimer(STOP_PACKET,0);
            
			break;
		}
            
            
        // Enviar pacote de trafego background
        case STOP_PACKET:{
            //cancelando envio de dados background, caso exista
            if(getTimer(SEND_PACKET) != -1){
                trace() << "Cancelado trafego de background existente!"; // around - debug
                cancelTimer(SEND_PACKET);
          
            }
            break;
        }
        
        // Enviar pacote source to sink
        case SEND_SRC2SINK_PACKET:{
/////            trace() << "Sending source2sink packet #" << src2snkSN; //around - debug
            //Appinfos()<<"S "<<SELF_NETWORK_ADDRESS<<" "<< src2snkSN;
            //Appinfos()<< "SRC-TO-SNK DATA: SENT BY " << SELF_NETWORK_ADDRESS << " TO SINK NODE " << s2sSinkId << " - NumSeq " << src2snkSN;
            
            //cancelando envio de dados background, caso exista
            if(getTimer(SEND_PACKET) != -1){
                trace() << "Cancelado trafego de background existente pra comecar S2S communcation!"; // around - debug
                cancelTimer(SEND_PACKET);
                // Após a comunicação SOURCE TO SINK, a comunicação de background retorna
                //setTimer(SEND_PACKET, (float (s2sDuration)) );
            }
            
            //Envia um pacote recem criado para a camada de rede
            AroundDataPacket *src2snkPkt = new AroundDataPacket("App Source to Sink Packet", APPLICATION_PACKET);
            src2snkPkt->setAroundDataPacketType(AROUND_DATA_SRC2SNK);
            src2snkPkt->setSourceNode(atoi(selfAddress.c_str()));
            src2snkPkt->setDestinationNode(s2sSinkId);
            src2snkPkt->setData(0);
            src2snkPkt->setSeqNumber(src2snkSN);
            src2snkPkt->setByteLength(AROUND_DATA_SRC2SNK_SIZE);
            
            toNetworkLayer(src2snkPkt, s2sSink.c_str());
            
            // Coletar estatísticas
            collectOutput("SRC-2-SNK Packets generated");
            s2sPacketsSent++;
            
            src2snkSN++;
            setTimer(SEND_SRC2SINK_PACKET, 1 / float (s2sRatePacket));
            
            //Definindo aqui o timer para parar o envio com base na quantidade máxima de pacotes definida (Duration)
            if(s2sPacketsSent == s2sDuration)
                setTimer(STOP_SRC2SINK_PACKET,0);
            
            break;
        }
            
        // Parar de enviar pacote source to sink
        case STOP_SRC2SINK_PACKET:{
            trace() << "ENTREI PARA PARAR O TRAFEGO SRC TO SNK!";  // around - debug
            //Interrompe o Timer de envio de pacotes source to sink
            if(getTimer(SEND_SRC2SINK_PACKET) != -1)
                cancelTimer(SEND_SRC2SINK_PACKET);
            
            // Após a comunicação SOURCE TO SINK, a comunicação de background retorna
            if(dataGen)
                setTimer(SEND_PACKET, packet_spacing); //ativo tomando por base o seu packet_spacing
            
            break;
        }
        
            
        // Enviar pacote Around Communication
        case SEND_AROUND_PACKET:{
/////            trace() << "Sending ARounD packet #" << aroundSN; //around - debug
            //Appinfos()<< "AROUND DATA: SENT BY " << SELF_NETWORK_ADDRESS << " - NumSeq " << aroundSN;
            
            //cancelando envio de dados background, caso exista
            if(getTimer(SEND_PACKET) != -1){
                trace() << "Cancelado trafego de background existente!"; // around - debug
                cancelTimer(SEND_PACKET);
            }
            
            //Configurar o pacote AROUND
            AroundDataPacket *aroundPkt = new AroundDataPacket("App ARounD Packet", APPLICATION_PACKET);
            aroundPkt->setAroundDataPacketType(AROUND_DATA_FLOW);
            aroundPkt->setSourceNode(atoi(selfAddress.c_str()));
            aroundPkt->setDestinationNode(-2);
            aroundPkt->setData(0);
            aroundPkt->setSeqNumber(aroundSN);
            aroundPkt->setByteLength(AROUND_DATA_AROUND_SIZE);

            toNetworkLayer(aroundPkt, "5000");
            
            // Coletar estatísticas
            collectOutput("ARounD Packets generated");
            aroundPacketsSent++;
            
            aroundSN++;
            setTimer(SEND_AROUND_PACKET, aroundRate);
            
            //Definindo aqui o timer para parar o envio com base na quantidade máxima de pacotes definida (Duration)
            if(aroundPacketsSent == aroundSentMAX){
                setTimer(STOP_AROUND_PACKET,0);
                
                //Enviando solicitação ao MAC para cancelar temporizadores AROUND
                AroundControlMessage *cmd = new AroundControlMessage("Around Communication Configuration", MAC_CONTROL_COMMAND);
                cmd->setAroundControlMessageKind(CANCEL_AROUND);
                cmd->setNum(0); //código do fluxo
                toNetworkLayer(cmd);
                
            }
            
            
            break;
        }
            
            
        // Para de enviar pacote Around Communication
        case STOP_AROUND_PACKET:{
            trace() << "ENTREI PARA PARAR O TRAFEGO AROUND!";  // around - debug
            //Interrompe o Timer de envio de pacotes source to sink
            if(getTimer(SEND_AROUND_PACKET) != -1)
                cancelTimer(SEND_AROUND_PACKET);
            
            // Após a comunicação AROUND, a comunicação de background retorna
//            if(packet_rate > 0)
//                setTimer(SEND_PACKET, packet_spacing); //ativo tomando por base o seu packet_spacing

            break;
        }
	}
}


void AroundApproachApp::handleMacControlMessage(cMessage *msg){
    trace() << "ENTREI NO HANDLE MAC CONTROL: "; //around - debug
    
    AroundControlMessage *cmd = check_and_cast <AroundControlMessage*>(msg);
    
    switch(cmd->getAroundControlMessageKind()) {
        
        case SET_RATE: {
            trace() << "ENTREI NO HANDLE MAC SET_RATE para ativar a geração de pacotes com datarate " << packet_rate; //around - debug
            
            // Se dataGen é true o node irá gerar dados (default é true). Caso contrário, o node não gerará dados de background.
            if(dataGen) {
                
                // Para implementação do journal de análise protocolar, packet_spacing é definido para cada node, ou seja
                // cada node tem seu próprio packet rate. Assim, as definições abaixo serão realizadas no início da aplicação
                //packet_rate = cmd->getParameter();
                //packet_spacing = packet_rate > 0 ? 1 / float (packet_rate) : -1;
            
                //trace() << packet_spacing + genk_dblrand(0)*0.05;
            
                if (packet_spacing > 0 && sinkAddress.compare(SELF_NETWORK_ADDRESS) != 0){ //acho que não é necessário esse sinkaddress.compare, pois o 0 nunca irá semear, nunca irá entrar aqui.
        
                    //double timeGen = 10 + genk_dblrand(0)*packet_spacing; //o 10 vem de mais ou menos dois períodos de BI a frente, considerando BO=8 (3,93s)
                    //trace() << "TEMPO GERAR: " << timeGen;
                    //setTimer(SEND_PACKET, packet_spacing + genk_dblrand(0)*100);  //Gera pacotes com tempos iniciais aleatórios (padrão 0.05, acredito que escolhi baseado na quantidade de 500 nós)
                    //setTimer(SEND_PACKET, timeGen);
                    
                    //Para a implementação do journal da analise protocolar, a geração de pacotes só começa agora quando recebe o primeiro beacon
                    setTimer(SEND_PACKET, 0);
                
                    //Defini um Timer STOP Packet para parar o envio de dados background a fim de poder analisar a taxa de pacotes perdidos.
                    // Assim, eu paro o envio de background antes do fim da simulação, dando tempo suficiente para todos os pacotes enviados de poderem tentar transmissão.
                    // Com isso, nenhum pacote é "deixado de tentar transmitir" simplesmente porque a simulação se finalizou.
                    //Como o timer SEND_PACKET é realizado mais ou menos no tempo 43 segundos, vou dar 100 segundos de comunicação
                    // Para isso, vou definir um tempo de simulação para uns 50 segundos a mais, ou seja, 43 + 100 + 50 = da perto dos 200
//                    setTimer(STOP_PACKET,100);
                }
                else
                    trace() << "Not sending packets"; //around - debug

            } else {
                trace() << "Not background data!"; //around - debug
            }
            
                
            break;
        }
            
        case BUFFER_FULL: {
            trace() << "ENTREI NO HANDLE MAC BUFFER_FULL DO NODE: " << SELF_NETWORK_ADDRESS; //around - debug
            
            collectOutput("BUFFER CHEIO");
            
            break;
        }
            
        case SET_AROUND: {
/////            trace() << "ENTREI NO HANDLE MAC SET_AROUND: "; //around - debug
            
            break;
        }
            
        case AUT_AROUND: {
            trace() << "ENTREI NO HANDLE MAC AUT_AROUND: " << cmd->getParameter(); //around - debug
            
            //Definindo o aroundRate
            aroundRate = 1 / cmd->getParameter();
            aroundSentMAX = cmd->getNum();
            
            trace() << "GERAR DADOS AROUND!!";
            trace() << "RATE: " << cmd->getParameter() << " que equivale em segundos: " << aroundRate;
            trace() << "MAX PACKETS: " << cmd->getNum();
            
            
            //Configurar geração e pacotes Around
            setTimer(SEND_AROUND_PACKET, genk_dblrand(0)*aroundRate); //começa a gerar pacote num número randomico entre o momento de autorização e a taxa de geração
            
            break;
        }
            
        default:{
            trace() << "WARNING: unknown control message type received [" << cmd->getName() << "]"; //around - debug
        
        }
    
    
    }
     
}



// This method processes a received carrier sense interupt. Used only for demo purposes
// in some simulations. Feel free to comment out the trace command.
void AroundApproachApp::handleRadioControlMessage(RadioControlMessage *radioMsg)
{
	switch (radioMsg->getRadioControlMessageKind()) {
		case CARRIER_SENSE_INTERRUPT:
			trace() << "CS Interrupt received! current RSSI value is: " << radioModule->readRSSI();
                        break;
	}
}

void AroundApproachApp::finishSpecific() {
    cTopology *topo;	// temp variable to access packets received by other nodes
    topo = new cTopology("topo");
    topo->extractByNedTypeName(cStringTokenizer("node.Node").asVector());
    
    declareOutput("Received Background Packets");
    declareOutput("Packets Reception Rate");
    declareOutput("Packets Loss Rate");
    declareOutput("Average end-to-end Delay");
    
    
    //iterator para os maps
    map<int,int>::const_iterator iter;
    

    // ------- pacotes de background recebidos -----------//
    // Devo escolher um dos procedimentos abaixo:
    // 1) Considerando que o nó root é o sink de todos os nós
    // 2) Mesmo que anterior, mas calculando as taxas baseado em cada nó e não no root
    // 3) considerando que cada CH é o sink dos seus nós
    
    // 1) Considerando que o nó root é o sink de todos os nós
    //Quantidade de pacotes background recebidos pelo sink
    
//    if(sinkAddress.compare(SELF_NETWORK_ADDRESS) == 0){
//    
//        declareOutput("Received Background Packets by the Sink Node");
//        //Taxa de recepção de pacotes
//        declareOutput("Packets Reception Rate");
//        //Taxa de perda de pacotes
//        declareOutput("Packets Loss Rate");
//        for(iter = packetsReceived.begin(); iter != packetsReceived.end(); iter++){
//            if(iter->second > 0){
//                collectOutput("Received Background Packets by the Sink Node", iter->first, "Per Nodes", iter->second);
//            
//                AroundApproachApp *appModule = dynamic_cast<AroundApproachApp*>
//                (topo->getNode(iter->first)->getModule()->getSubmodule("Application"));
//
//                int pktsSent = appModule->getPacketsSent();
//                float rate = (float)packetsReceived[iter->first]/pktsSent;
//                collectOutput("Packets Reception Rate", iter->first, "Total", rate);
//                collectOutput("Packets Loss Rate", iter->first, "Total", 1-rate);
//            }
//        }
//    }
    
    
    
    // 2) Considerando que o nó root é o sink de todos os nós
    //    Root gera a estatística, porém fiz de um jeito para considerar caso não receba pacotes de algum nó que gerou pacotes
    if(sinkAddress.compare(SELF_NETWORK_ADDRESS) == 0){
//        declareOutput("Received Background Packets by the Sink Node");
        //Taxa de recepção de pacotes
//        declareOutput("Packets Reception Rate");
        //Taxa de perda de pacotes
//        declareOutput("Packets Loss Rate");
        //Delay acumulado dos pacotes recebidos
        //declareOutput("Average end-to-end Delay");
       
        //Rodando todos os nós
        for(int i = 0; i < numNodes; i++){

            //Pegando o módulo de cada um dos nós
            AroundApproachApp *appModule = dynamic_cast<AroundApproachApp*>
            (topo->getNode(i)->getModule()->getSubmodule("Application"));
            
            int pktsSent = appModule->getPacketsSent();
            
/////            trace() << "NODE " << i << " GEROU QUANT PACOTES: " << pktsSent;
            
            if(pktsSent > 0){ //Procurando nós que geraram pacotes de dados
/////                trace() << "ENTREI PARA ESTATISTICA: " << i;
                collectOutput("Received Background Packets", i, "Sink Node", packetsReceived[i]);
                
                //Coletando as taxas de recebimento e de perca
                float rate = (float) packetsReceived[i] / pktsSent;
                collectOutput("Packets Reception Rate", i, "Total", rate);
                collectOutput("Packets Loss Rate", i, "Total", 1-rate);
                
/////                trace() << "PARA NODE " << i << " GANHO E PERCA: " << rate << " - " << 1-rate;
                
                //Coletando o end-to-end delay médio
                if(packetsReceived[i] > 0){
                    //double avDelay = SIMTIME_DBL(averageDelay[i]);
                    //collectOutput("Average end-to-end Delay", i, "Total", SIMTIME_DBL(averageDelay[i])/packetsReceived[i]);
                    collectOutput("Average end-to-end Delay", i, "Total", averageDelay[i]/packetsReceived[i]);
                } else {
                    collectOutput("Average end-to-end Delay", i, "Total", 0);
                }
            }
        }
    }
    
    
    
    
//    if(packetsSent > 0){
//        //Quantidade de pacotes background recebidos pelo sink
//        declareOutput("Background Packets received");
//        //Taxa de recepção de pacotes
//        declareOutput("Packets Reception Rate");
//        //Taxa de perda de pacotes
//        declareOutput("Packets Loss Rate");
//        
//        //Pegando o módulo do nó sink
//        AroundApproachApp *appModule = dynamic_cast<AroundApproachApp*>
//        (topo->getNode(sinkId)->getModule()->getSubmodule("Application"));
//        
//        //Coletando os pacotes recebidos nos sink
//        collectOutput("Background Packets received", appModule->getPacketsReceived(atoi(selfAddress.c_str())));
//        
//        //Coletando as taxas
//        float rate = (float) appModule->getPacketsReceived(atoi(selfAddress.c_str())) / packetsSent;
//        collectOutput("Packets Reception Rate", atoi(selfAddress.c_str()) , "Total", rate);
//        collectOutput("Packets Loss Rate", atoi(selfAddress.c_str()), "Total", 1-rate);
//    
//    
//    }
    
    
    
    
    // 3) considerando que cada CH é o sink dos seus nós
    //Quantidade de pacotes background recebidos por um CH de seus nós associados
//    declareOutput("Background Packets received");
//    //Taxa de recepção de pacotes
//    declareOutput("Packets Reception Rate");
//    //Taxa de perda de pacotes
//    declareOutput("Packets Loss Rate");
//    map<int,int>::const_iterator iter;
//    for(iter = packetsReceived.begin(); iter != packetsReceived.end(); iter++){
//        if(iter->second > 0){
//            collectOutput("Background Packets received", iter->first, "Per Cluster-Head", iter->second);
//            
//            AroundApproachApp *appModule = dynamic_cast<AroundApproachApp*>
//            (topo->getNode(iter->first)->getModule()->getSubmodule("Application"));
//            //bytesDelivered += appModule->getBytesReceived(iter->first);
//            int packetsSent = appModule->getPacketsSent();
//            float rate = (float)packetsReceived[iter->first]/packetsSent;
//            collectOutput("Packets Reception Rate", iter->first, "Total", rate);
//            collectOutput("Packets Loss Rate", iter->first, "Total", 1-rate);
//        }
//    }
    
    
    
    //Quantidade de pacotes source-2-sink enviados por cada nó semeador
    if(s2sPacketsSent > 0){
        declareOutput("Source-to-Sink Packets generated");
        collectOutput("Source-to-Sink Packets generated", "", s2sPacketsSent);
    }
    
    //Quantidade de pacotes source-2-sink recebidos por um nó (naturalmente um Sink)
    declareOutput("Source-to-Sink Packets received");
    //Taxa de recepção de pacotes
    declareOutput("S2S Packets Reception Rate");
    //Taxa de perda de pacotes
    declareOutput("S2S Packets Loss Rate");
    //Average end-to-end Delay for Tree flow
    declareOutput("Tree Flow Average end-to-end Delay");
    //map<int,int>::const_iterator iter;
    for(iter = s2sPacketsReceived.begin(); iter != s2sPacketsReceived.end(); iter++){
        if(iter->second > 0){
            collectOutput("Source-to-Sink Packets received", iter->first, "Per Sink", iter->second);
            
            AroundApproachApp *s2sappModule = dynamic_cast<AroundApproachApp*>
            (topo->getNode(iter->first)->getModule()->getSubmodule("Application"));
            //bytesDelivered += appModule->getBytesReceived(iter->first);
            int s2sPacketsSent = s2sappModule->getS2SPacketsSent();
            float rate2 = (float)s2sPacketsReceived[iter->first]/s2sPacketsSent;
            collectOutput("S2S Packets Reception Rate", iter->first, "Total", rate2);
            collectOutput("S2S Packets Loss Rate", iter->first, "Total", 1-rate2);
            
            //Coletando o atraso médio do fluxo Tree
            //collectOutput("Tree Flow Average end-to-end Delay", iter->first, "Total", SIMTIME_DBL(s2sAverageDelay[iter->first])/iter->second);
            collectOutput("Tree Flow Average end-to-end Delay", iter->first, "Total", s2sAverageDelay[iter->first]/iter->second);
        }
    }
    
    
    //Quantidade de pacotes around gerado pelo node source
    if(aroundPacketsSent > 0){
        declareOutput("Generated Around Packets");
        collectOutput("Generated Around Packets", "", aroundPacketsSent);
    }
    
    //Quantidade de pacotes source-2-sink recebidos por um nó (naturalmente um Sink)
    declareOutput("Received Around Packets");
    //Taxa de recepção de pacotes
    declareOutput("Around Reception Rate");
    //Taxa de perda de pacotes
    declareOutput("Around Loss Rate");
    //Average end-to-end Delay for Around flow
    declareOutput("Around Average end-to-end Delay");
    //map<int,int>::const_iterator iter;
    for(iter = aroundPacketsReceived.begin(); iter != aroundPacketsReceived.end(); iter++){
        if(iter->second > 0){
            collectOutput("Received Around Packets", iter->first, "Around Flow", iter->second);
            
            AroundApproachApp *aroundAppModule = dynamic_cast<AroundApproachApp*>
            (topo->getNode(iter->first)->getModule()->getSubmodule("Application"));
            
            int aroundSent = aroundAppModule->getAroundPacketsSent();
            double rate3 = (double)aroundPacketsReceived[iter->first] / aroundSent;
            collectOutput("Around Reception Rate", iter->first, "Total", rate3);
            collectOutput("Around Loss Rate", iter->first, "Total", 1-rate3);
            
            //Coletando o atraso médio do fluxo Around
            //collectOutput("Around Average end-to-end Delay", iter->first, "Total", SIMTIME_DBL(aroundAverageDelay[iter->first])/iter->second);
            collectOutput("Around Average end-to-end Delay", iter->first, "Total", aroundAverageDelay[iter->first]/iter->second);
        }
    }
    
    
    
    
    delete(topo);
    
}


// Configurando Fluxos AROUND
void AroundApproachApp::aroundFlowConfiguration(){
    ifstream file("flowConfig.ini");
    
    if (!file.is_open()){
        //trace() << "Error reading from parameters file aroundFlows.ini";
        //opp_error("Error reading from parameters file aroundFlows.ini");
        trace() << "Not Around Configuration"; //around - debug
        return;
    }
    
    string s;
    while(getline(file, s)) {
        
        // Removendo comentários, espaços, tabulações e quebras de linha
        size_t pos = s.find('#');
        if (pos != string::npos)
            s.replace(s.begin() + pos, s.end(), "");
        
        // find and remove unneeded spaces
        pos = s.find_last_not_of(" \t\n");
        if (pos != string::npos) {
            s.erase(pos + 1);
            pos = s.find_first_not_of(" \t\n");
            if (pos != string::npos)
                s.erase(0, pos);
        } else
            s.erase(s.begin(), s.end());
        
        if (s.length() == 0)
            continue;
        
        
        //trace() << s;  //around - debug
        int a,b,e;
        float c,d;
        const char *ct = NULL;
        char *ctmp;
        
        cStringTokenizer t(s.c_str(), " ");
        ct = t.nextToken();
        a = stoi(ct); //source
        ct = t.nextToken();
        b = stoi(ct); //destination
        ct = t.nextToken();
        c = strtof(ct, &ctmp); //packetrate
        ct = t.nextToken();
        d = strtof(ct, &ctmp); //startime
        ct = t.nextToken();
        e = stoi(ct); //duration
        //trace() << "VALOR DE A " << a; //around - debug
        //trace() << "VALOR DE B " << b; //around - debug
        //trace() << "VALOR DE C " << c; //around - debug
        //trace() << "VALOR DE D " << d; //around - debug
        //trace() << "VALOR DE E " << e; //around - debug
        
        struct aroundconf var;
        var.src = a;
        var.dst = b;
        var.packetrate = c;
        var.starttime = d;
        var.duration = e;
        
        aroundFlows.push_back(var);
    }
    
    // Ordenando o vector com base no start time
    struct aroundconf aux;
    for(int i = 0; i < aroundFlows.size(); i++){
        for(int j = i; j < aroundFlows.size(); j++){
            if(aroundFlows[i].starttime > aroundFlows[j].starttime){
                aux = aroundFlows[i];
                aroundFlows[i]=aroundFlows[j];
                aroundFlows[j]=aux;
            } 
        } 
    }
    
    //vector <struct aroundconf>::const_iterator iter;
    vector <struct aroundconf>::iterator iter;
    
    //Around - Debug: Impressão dos fluxos Around
    for(iter = aroundFlows.begin(); iter != aroundFlows.end(); iter++){
        trace() << "FLuxo com inicio em: " << iter->starttime; //around - debug
        trace() << "Origem: " << iter->src; //around - debug
        trace() << "Destino: " << iter->dst; //around - debug
        trace() << "Packet Rate: " << iter->packetrate; //around - debug
        trace() << "Duracao: " << iter->duration; //around - debug
        trace() << ""; //around - debug
    }
    
    // Configurando primeiro Fluxo
    iter = aroundFlows.begin();
    setTimer(AROUND_FLOW,iter->starttime - getClock());
    
}
