/*******************************************************************************
 *  Copyright: National ICT Australia,  2007 - 2010                            *
 *  Developed at the ATP lab, Networked Systems research theme                 *
 *  Author(s): Athanassios Boulis, Dimosthenis Pediaditakis, Yuriy Tselishchev *
 *  This file is distributed under the terms in the attached LICENSE file.     *
 *  If you do not find this file, copies can be found by writing to:           *
 *                                                                             *
 *      NICTA, Locked Bag 9013, Alexandria, NSW 1435, Australia                *
 *      Attention:  License Inquiry.                                           *
 *                                                                             *  
 *******************************************************************************/

#ifndef _RESOURCEMANAGER_H_
#define _RESOURCEMANAGER_H_

#include <map>
#include "CastaliaModule.h"
#include "ResourceManagerMessage_m.h"
#include <math.h>

#define LIMIT 0.0001

using namespace std;

enum ResoruceManagerTimers {
	PERIODIC_ENERGY_CALCULATION = 1,
};

class ResourceManager: public CastaliaModule {
 private:
	// parameters and variables
	/*--- The .ned file's parameters ---*/
	double sigmaCPUClockDrift;
	double cpuClockDrift;
	double initialEnergy;
	double ramSize;
	double baselineNodePower;
	double currentNodePower;
	simtime_t timeOfLastCalculation;
	double periodicEnergyCalculationInterval;

	/*--- Custom class parameters ---*/
	double remainingEnergy;
	double totalRamData;

	map<int,double> storedPowerConsumptions;

	cMessage *energyMsg;
	bool disabled;
	
	// Begin of T-KiBaM requirements ****************************************************************/
	// Developed at Federal University of Santa Catarina, Automation and Systems Department.
	// Author: Leonardo Martins Rodrigues. E-mail: l.m.rodrigues at posgrad.ufsc.br
	// Date: 2015-2016-2017
	// Background: in this implementation, we use the Kinetic Battery Model (KiBaM) as the battery
	//             model in Castalia Simulator. More details about this model can be found in the
	//             following paper: J. F. Manwell and J. G. McGowan. Lead Acid Battery Storage Mod-
	//             el for Hybrid Energy Systems. Solar Energy. Vol. 50, No. 5, pp. 399-405. 1993.
	//             This implementation also contains some modifications in the battery model, which
	//             are described in the following paper: L. M. Rodrigues, C. Montez, R. Moraes, P.
	//             Portugal and F. Vasques. A Temperature-Dependent Battery Model for Wireless Sen-
	//             sor Networks. Sensors. 17(2). 422. 2017. doi:10.3390/s17020422; and in: L. M.
	//             Rodrigues, C. Montez, G. Budke, F. Vasques and P. Portugal. Estimating the Life-
	//             time of Wireless Sensor Network Nodes through the Use of Embedded Analytical Bat-
	//             tery Models. Journal of Sensor and Actuator Networks, 6(2), 2017. doi: 10.3390/
	//             jsan6020008.
	//             Please feel free to contact and suggest improvements.
	
	// T-KiBaM parameters.
	double yo;           // in As (Amphere-second). The actual battery capacity.
	double io;           // in As. Available Charge Tank initial content.
	double i;            // in As. Available Charge Tank actual content.
	double jo;           // in As. Bound Charge Tank initial content.
	double j;            // in As. Bound Charge Tank actual content.
	double c;            // in percentage (0,1). E.g.: 0.115.
	double k;            // in 1/sec. Rate constant.

	// Castalia related parameters.
	int precisionValue;  // Precision value when trace is used. E.g.: 18 -> 2429.98835170749499
	int traceInterval;   // in seconds. Sets the interval for printing information in CastaliaTrace.txt.
	bool kibamModel;     // true (use the T-KiBaM) or false (use the original battery model).
	double nV;           // in V (Volts). The Battery Nominal Voltage.
	double elt;          // in s. Estimated battery LifeTime.
	double y_mAh;        // in mAh. The battery capacity.
	double i_avg;        // in mA. The average current consumption.
	double t_sum[2];     // The sum of currents (i, in milli-Amp) and their times (t, in seconds). Ex.: [i*t, t].
			     // These values are used to calculate the average discharge current of the node.
	
	// Arrhenius equation parameters.
	double A;            // in 1/sec. The pre-factor constant.
	double Ea;           // in KJ/mol. The activation energy.
	double R;            // in KJ/mol K. The universal gas constant.
	double T;            // in Kelvin (K). The ambient temperature.
	
	// Temperature-Dependent Voltage Model (TVM).
	double Vb;           // in V. Battery Voltage.
	double Eo;           // in V. Battery nominal voltage value.
	double Rv;           // in Ohm. Internal Resistence.
	double Kv;           // in Ohm. Polarisation Resistence.
	double Av;           // in V. Exponential Zone Amplitude.
	double Bv;           // in 1/Ah. Exponential Zone Time Constant Inverse.
	double Expt;         // Exp(t), used for Ni-MH battery type.
	double it;           // in Ah. The actual battery charge.
	double Qb;           // in Ah. The total battery capacity.
	double tau_b;        // Smoothing constant.
	
	// End of T-KiBaM requirements ******************************************************************/

 protected:
	virtual void initialize();
	virtual void handleMessage(cMessage * msg);
	virtual void finishSpecific();
	void calculateEnergySpent();
	void startKibam();                                         // T-KiBaM requirement
	double correctionFactor(double T);                         // T-KiBaM requirement
	double arrhenius(double A, double Ea, double R, double T); // T-KiBaM requirement

 public:
	double getCPUClockDrift(void);
	void consumeEnergy(double amount);
	double getSpentEnergy(void);
	double estimateLifetime();
	void destroyNode(void);
	int RamStore(int numBytes);
	void RamFree(int numBytes);
	double kibam(double t, double I);                          // T-KiBaM requirement
	void setT(double Treceived);                               // T-KiBaM requirement
};

#endif				// _RESOURCEGENERICMANAGER_H_
