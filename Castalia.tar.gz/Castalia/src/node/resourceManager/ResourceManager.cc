/*******************************************************************************
 *  Copyright: National ICT Australia,  2007 - 2012                            *
 *  Developed at the ATP lab, Networked Systems research theme                 *
 *  Author(s): Athanassios Boulis, Dimosthenis Pediaditakis, Yuriy Tselishchev *
 *  This file is distributed under the terms in the attached LICENSE file.     *
 *  If you do not find this file, copies can be found by writing to:           *
 *                                                                             *
 *      NICTA, Locked Bag 9013, Alexandria, NSW 1435, Australia                *
 *      Attention:  License Inquiry.                                           *
 *                                                                             *  
 *******************************************************************************/

#include "ResourceManager.h"
#include "ThroughputTest.h"
#include "Basic802154.h"
#include "stdlib.h"

Define_Module(ResourceManager);

void ResourceManager::initialize()
{	
	sigmaCPUClockDrift = par("sigmaCPUClockDrift");
	//using the "0" rng generator of the ResourceManager module
	cpuClockDrift = normal(0, sigmaCPUClockDrift);
	/* Crop any values beyond +/- 3 sigmas. Some protocols (e.g., MAC) rely on
	 * bounded cpuClockDrift. Although the bounds are conservative (usually 3sigmas),
	 * if you instantiate thousands of nodes (in multiple runs) we will get a
	 * couple of nodes that will be beyond this bound. Limiting/Croping the drift
	 * is actually realistic, since usually there is some kind of quality
	 * control on quartz crystals or the boards that use them (sensor node)
	 */
	if (cpuClockDrift > 3 * sigmaCPUClockDrift)
		cpuClockDrift = 3 * sigmaCPUClockDrift;
	if (cpuClockDrift < -3 * sigmaCPUClockDrift)
		cpuClockDrift = -3 * sigmaCPUClockDrift;

	initialEnergy = par("initialEnergy");
	ramSize = par("ramSize");
	baselineNodePower = par("baselineNodePower");
	periodicEnergyCalculationInterval = (double)par("periodicEnergyCalculationInterval") / 1000;

	if (baselineNodePower < 0 || periodicEnergyCalculationInterval < 0)
		opp_error("Illegal values for baselineNodePower and/or periodicEnergyCalculationInterval in resource manager module");

	currentNodePower = baselineNodePower;
	remainingEnergy = initialEnergy;
	totalRamData = 0;
	disabled = true;
	
	// T-KiBaM requirement.
	T = (double) par("T");   // Initializing the value of T, which is updated by the application.
	startKibam();
}

void ResourceManager::calculateEnergySpent()
{
	if (remainingEnergy > 0) {
		simtime_t timePassed = simTime() - timeOfLastCalculation;
		
		if(!kibamModel){
			// If not using T-KiBaM, apply the original energy model.
			consumeEnergy(SIMTIME_DBL(timePassed * currentNodePower / 1000.0));
		}else{
			// T-kibam Parameters: time (s), discharge current (A).
			consumeEnergy(kibam(SIMTIME_DBL(timePassed), (currentNodePower/1000.0)/nV ));
		}

		timeOfLastCalculation = simTime();
		
		cancelEvent(energyMsg);
		scheduleAt(simTime() + periodicEnergyCalculationInterval, energyMsg);
	}
}

/* The ResourceManager module has only one "unconnected" port where it can receive messages that
 * update the power drawn by a module, or a NODE_STARTUP message. If disabled we still process
 * messages because we want to have the latest power drawn from any module.
 */
void ResourceManager::handleMessage(cMessage * msg)
{

	switch (msg->getKind()) {

		case NODE_STARTUP:{
			disabled = false;
			timeOfLastCalculation = simTime();
			energyMsg = new cMessage("Periodic energy calculation", TIMER_SERVICE);
        		scheduleAt(simTime() + periodicEnergyCalculationInterval, energyMsg);
			break;
		}
	
		case TIMER_SERVICE:{
			calculateEnergySpent();
			return;
		}

		case RESOURCE_MANAGER_DRAW_POWER:{
			ResourceManagerMessage *resMsg = check_and_cast<ResourceManagerMessage*>(msg);
			int id = resMsg->getSenderModuleId();
			double oldPower = storedPowerConsumptions[id];
			// trace() << "New power consumption, id = " << id << ", oldPower = " <<
			// 		currentNodePower << ", newPower = " <<
			// 		currentNodePower - oldPower + resMsg->getPowerConsumed();
			if (!disabled)
				calculateEnergySpent();
			currentNodePower = currentNodePower - oldPower + resMsg->getPowerConsumed();
			storedPowerConsumptions[id] = resMsg->getPowerConsumed();
			break;
		}

		default:{
			opp_error("ERROR: Unexpected message received by resource manager: %s", msg->getKind());
		}
	}
	delete msg;
}

void ResourceManager::finishSpecific()
{
	calculateEnergySpent();
	declareOutput("Consumed Energy");
	collectOutput("Consumed Energy", "", initialEnergy - remainingEnergy);
	declareOutput("Remaining Energy");
	collectOutput("Remaining Energy", "", remainingEnergy);

	if (getParentModule()->getIndex() == 0) {
		cTopology *topo;	// temp variable to access energy spent by other nodes
		topo = new cTopology("topo");
		topo->extractByNedTypeName(cStringTokenizer("node.Node").asVector());

		double minLifetime = estimateLifetime();
		for (int i = 1; i < topo->getNumNodes(); i++) {
			ResourceManager *resMng = dynamic_cast<ResourceManager*>
				(topo->getNode(i)->getModule()->getSubmodule("ResourceManager"));
			if (minLifetime > resMng->estimateLifetime()) 
				minLifetime = resMng->estimateLifetime();
		}
		declareOutput("Estimated network lifetime (days)");
		collectOutput("Estimated network lifetime (days)", "", minLifetime);
		delete(topo);
	}
}

double ResourceManager::estimateLifetime(void) 
{
	// Using the Original Model to estimate the battery lifetime.
	double lt;
	lt = ((initialEnergy * simTime().dbl()) / ((initialEnergy - remainingEnergy) * 86400.0));
	trace() << std::setprecision(precisionValue) << "ELT = " << lt;
	return lt;
	
	// To-Do:
	// Estimate the battery lifetime using the T-KiBaM model.
}

double ResourceManager::getSpentEnergy(void)
{
	Enter_Method("getSpentEnergy()");
	return (initialEnergy - remainingEnergy);
}

double ResourceManager::getCPUClockDrift(void)
{
	Enter_Method("getCPUClockDrift(void)");
	return (1.0f + cpuClockDrift);
}

void ResourceManager::consumeEnergy(double amount)
{
	Enter_Method("consumeEnergy(double amount)");
	
	if (remainingEnergy <= amount) {
		remainingEnergy = 0;
		send(new cMessage("Destroy node message", OUT_OF_ENERGY), "toSensorDevManager");
		send(new cMessage("Destroy node message", OUT_OF_ENERGY), "toApplication");
		send(new cMessage("Destroy node message", OUT_OF_ENERGY), "toNetwork");
		send(new cMessage("Destroy node message", OUT_OF_ENERGY), "toMac");
		send(new cMessage("Destroy node message", OUT_OF_ENERGY), "toRadio");
		disabled = true;
		// Collecting the moment of death of the node.
		declareOutput("Dead Node");
		collectOutput("Dead Node", "yes?", 1);
		collectOutput("Dead Node", "time (h)", SIMTIME_DBL(simTime())/3600.0);
	} else
		remainingEnergy -= amount;
		
	// T-KiBaM - Information to plot figures: TIME, REMAINING_ENERGY, STATE_OF_CHARGE, VOLTAGE
	if((int)simTime().dbl() % traceInterval == 0){
		if (amount != 0.0){
			if (Vb >= 0)
				trace() << std::setprecision(precisionValue) << remainingEnergy << " " << remainingEnergy/initialEnergy * 100 << " " << Vb;
			else
			trace() << std::setprecision(precisionValue) << remainingEnergy << " " << remainingEnergy/initialEnergy * 100 << " " << "0";
		}
	}
}

void ResourceManager::destroyNode(void)
{
	Enter_Method("destroyNode(void)");

	send(new cMessage("Destroy node message", DESTROY_NODE), "toSensorDevManager");
	send(new cMessage("Destroy node message", DESTROY_NODE), "toApplication");
	send(new cMessage("Destroy node message", DESTROY_NODE), "toNetwork");
	send(new cMessage("Destroy node message", DESTROY_NODE), "toMac");
	send(new cMessage("Destroy node message", DESTROY_NODE), "toRadio");
	disabled = true;
    	declareOutput("Dead Node");
	collectOutput("Dead Node", "yes?", 1);
	collectOutput("Dead Node", "time", SIMTIME_DBL(simTime()));
}

int ResourceManager::RamStore(int numBytes)
{
	Enter_Method("RamStore(int numBytes)");

	int ramHasSpace = ((totalRamData + numBytes) <= ramSize) ? 1 : 0;
	if (!ramHasSpace) {
		trace() << "\n[Resource Manager] t= " << simTime() <<
				": WARNING: Data not stored to Ram. Not enough space to store them.";
		return 0;
	} else
		totalRamData += numBytes;
	return 1;
}

void ResourceManager::RamFree(int numBytes)
{
	Enter_Method("RamFree(int numBytes)");
	totalRamData -= numBytes;
	totalRamData = (totalRamData < 0) ? 0 : totalRamData;
}



// Begin of T-KiBaM requirements ****************************************************************/
// Developed at Federal University of Santa Catarina, Automation and Systems Department.
// Author: Leonardo Martins Rodrigues. E-mail: l.m.rodrigues at posgrad.ufsc.br
// Date: 2015-2016-2017
// Background: in this implementation, we use the Kinetic Battery Model (KiBaM) as the battery
//             model in Castalia Simulator. More details about this model can be found in the
//             following paper: J. F. Manwell and J. G. McGowan. Lead Acid Battery Storage Mod-
//             el for Hybrid Energy Systems. Solar Energy. Vol. 50, No. 5, pp. 399-405. 1993.
//             This implementation also contains some modifications in the battery model, which
//             are described in the following paper: L. M. Rodrigues, C. Montez, R. Moraes, P.
//             Portugal and F. Vasques. A Temperature-Dependent Battery Model for Wireless Sen-
//             sor Networks. Sensors. 17(2). 422. 2017. doi:10.3390/s17020422; and in: L. M.
//             Rodrigues, C. Montez, G. Budke, F. Vasques and P. Portugal. Estimating the Life-
//             time of Wireless Sensor Network Nodes through the Use of Embedded Analytical Bat-
//             tery Models. Journal of Sensor and Actuator Networks, 6(2), 2017. doi: 10.3390/
//             jsan6020008.
//             Please feel free to contact and suggest improvements.

// Protected Method. It returns the Arrhenius constant value used to adjust several parameters.
double ResourceManager::arrhenius(double A, double Ea, double R, double T)
{
	return (A * exp(-Ea/(R*T)) );
}

// Protected Method. It returns the correction factor used in T-KiBaM simulation.
double ResourceManager::correctionFactor(double T)
{
	double cf;
	double t = T;
	
	// Smoothing Spline (Piecewise Polynomial function): f(T) = a*T^3 + b*T^2 + c*T^1 + d*T^0;
	// Coefficients (a,b,c,d):
	const double v[4][4] =
		{
			{-0.000000511703942, 0                , 0.001007597134289, 0.998002046815767},
			{0.000002237539379, -0.000023026677378, 0.000662196973612, 1.011389003026715},
			{-0.000020925117234, 0.000077662594698, 0.001481735733400, 1.023692650626454},
			{0.000017473446358, -0.000393152543066, -0.000884438879363, 1.030346405745630}
		};
	if(t >= -5.0 && t <= 40.0){
	    if(t >= -5.0 && t < 10.0)
	        cf = v[0][0]*pow((t+5),3) + v[0][1]*pow((t+5),2) + v[0][2]*pow((t+5),1) + v[0][3];
	    
	    if(t >= 10.0 && t < 25.0)
	        cf = v[1][0]*pow((t-10),3) + v[1][1]*pow((t-10),2) + v[1][2]*pow((t-10),1) + v[1][3];

	    if(t >= 25.0 && t < 32.5)
	        cf = v[2][0]*pow((t-25),3) + v[2][1]*pow((t-25),2) + v[2][2]*pow((t-25),1) + v[2][3];

	    if(t >= 32.5 && t <= 40.0)
	        cf = v[3][0]*pow((t-32.5),3) + v[3][1]*pow((t-32.5),2) + v[3][2]*pow((t-32.5),1) + v[3][3];
	}
	
	return cf;   // Returning the correction factor for the battery initial capacity.
}

// Protected Method. It initializes all the T-KiBaM parameters and checks its values.
void ResourceManager::startKibam()
{
	double T_k;                             // Temperature in Kelvin.

	kibamModel = par("kibamModel");         // Use the T-KiBaM or the original battery model?
	precisionValue = par("precisionValue"); // Sets the precision value (used in trace() calls).
	traceInterval = par("traceInterval");   // Sets the interval for printing information in CastaliaTrace.txt (in seconds).

	T_k = T + 273.15;                       // Initializes the temperature, from Celsius to Kelvin.

	// Print in CastaliaTrace the current temperature (in Celsius degree).
	// trace() << "Environment: Current Temperature = " << T;

	// Checking if the T-KiBaM is the battery model to be used in the simulation.
	if(kibamModel){
		
		// Test if the simulation is at the beginning.
		if(simTime().dbl() == 0){

			// Arrhenius equation parameters from .ini file.
			A  = par("A");                      // Sets the pre-factor.
			Ea = par("Ea");                     // Sets the activation energy.
			R  = par("R");                      // The universal gas constant.
			
			// T-KiBaM parameters from .ini file.			
			nV = par("nV");                     // Sets the battery nominal voltage.
			c  = par("c");                      // Sets the charge fraction in Available Charge tank.

			// Checking if the battery nominal voltage is greater than zero.
			if (nV < 0)
				opp_error("Illegal value for nV (Battery Nominal Voltage) in resource manager module");

			// Checking if the Available Charge tank width is in the range (0,1].
			if (c <= 0 || c > 1)
				opp_error("Illegal value for c (Available Charge tank width) in resource manager module");

			// Initializing T-KiBaM and TVM parameters.
			i = 0.0;
			j = 0.0;
			elt = 0.0;

			it = 0.0;
			Vb = 0.0;
			
			for(int g=0; g<2; g++)	t_sum[g] = 0.0;
			
			yo = (initialEnergy / nV);	// Initial battery capacity. Joule -> As: As = J / V.
			io = (c * yo);                  // Initializes the Available Charge tank capacity.
			jo = ((1-c) * yo);              // Initializes the Bound Charge tank capacity.
			
			// Adjusting the simulator parameters to work according the T-KiBaM model.
			initialEnergy = io * nV;        // Redefining the initial energy (It is equal to the Available
		                                        // Charge tank capacity).
			remainingEnergy = io * nV;      // The remaining energy is also equal to the initial Available
				                        // Charge tank capacity.
			
		}else{
			
			// Compute the estimated lifetime according to the task array.
			double lt;
        		lt = ( y_mAh * correctionFactor(T)) / (i_avg * 1000);
        		
        		// Add/Remove charge capacity in each hour.
		        y_mAh = y_mAh + (y_mAh * (correctionFactor(T) - 1.000) / lt);
		        
		        yo = 3.6 * y_mAh;  		// Applies the correction factor to the battery capacity.
			io = (c * yo);                  // Initializes the Available Charge tank capacity.
			jo = ((1-c) * yo);              // Initializes the Bound Charge tank capacity.
			remainingEnergy = io * nV;      // The remaining energy is also equal to the initial Available
				                        // Charge tank capacity.
		
			k  = arrhenius (A,Ea,R,T_k);    // Sets the rate constant according to Arrhenius equation.

			
			// Voltage Modelling parameters.
			// Source: Experimental Validation of a Battery Dynamic Model for EV Applications - O. Tremblay and Louis-A. Dessaint.
			// The following values are valid for a Ni-MH battery (Panasonic HHR-4MRT/2BB, 750 mAh, 2 x 1.2 V).
			// L. M. Rodrigues, C. Montez, R. Moraes, P. Portugal and F. Vasques. A Temperature-Dependent Battery
			// Model for Wireless Sensor Networks. Sensors. 17(2). 422. 2017. doi:10.3390/s17020422
			Av = 0.4831;
			Eo = arrhenius(2.884194576613940,0.257138414788235,R,T_k);
			Rv = arrhenius(0.000071344680888,-15.357723400214100,R,T_k);
			Kv = arrhenius(0.000234004626789,-11.318113750679100,R,T_k);
			Bv = arrhenius(0.584664335270996,-7.640349444750650,R,T_k);
			tau_b = arrhenius(1.126795666175170,0.369782934961201,R,T_k);
		}
	}
}


// Public Method. It runs the model, refreshing the content in both tanks: Available and Bound Charge.
double ResourceManager::kibam(double t, double I)
{
	Enter_Method("kibam(double t, double I)");
	
	// Variable to check if the content of the Available Charge tank increases (recovery effect) or 
	// decreases (discharging the battery).
	double old_io = io;
	
	// Battery voltage temporary variables.
	double Exp;
	double y;
	double Ts;
	
	// Check if the content of the parameters are valid.
	if(t == 0 && I == 0){
		return 0.0;
	}
	
	// Computing the average current consumption.
	t_sum[0] = t_sum[0] + (I * t);
	t_sum[1] = t_sum[1] + (t);
	
	
	// Debug purpose.
	// trace() << std::setprecision(precisionValue) << "t (s): " << t << " | I (A): " << I;
	
	// Compute new values using KiBaM equations.
	i = (io * exp(- k * t)) + ((((yo * k * c) - I)*(1 - exp(- k * t))) / k) - (I * c * ((k * t) - 1 + exp(- k * t)) / k);
	j = (jo * exp(- k * t)) + (yo * (1 - c) * (1 - exp(- k * t))) - ((I * (1 - c) * ((k * t) - 1 + exp(- k * t))) / k);

	// Update variables.
	io = i;
	jo = j;
	
	yo = io + jo;   // 'yo' needs to be in As.
	
	// Computing estimated lifetime.
	elt += t;
	
	// Updating the battery voltage.
	y = Qb * 5/18 * 0.001;                                              // Converting As -> Ah.
	Ts = t / 3600;                                                      // in hours.
	it = it + (I * Ts);                                                 // in Ah.
	Exp = (1/(1+(Bv*I*Ts*tau_b)))*Expt;                                 // Compute Exp(t).
	Expt = Exp;                                                         // Update Exp(t-1).
	Vb = Eo - (Rv*I) - (Kv*(y/(y-(it*tau_b)))*((it*tau_b)+I)) + Exp;    // Compute V.
	
	// Debug purpose.
	// trace() << std::setprecision(precisionValue) << "," << Vb;
	
	return (old_io - io) * nV; // Convert to Joules by multiplying by nV.
}


void ResourceManager::setT(double Treceived){
	T = Treceived;
	// trace() << "Environment: Temperature Change!";
	
	if(kibamModel){
	
		// Compute the average current consumption.
		i_avg = t_sum[0] / t_sum[1];
		t_sum[0] = 0.0;
		t_sum[1] = 0.0;

		// Discovering T-KiBaM Periof of refresh.
		int period;
		ThroughputTest *appModule;
		appModule = check_and_cast <ThroughputTest*>(getParentModule()->getSubmodule("Application"));
		period = appModule->getKibamPeriod();
		
		// All the things that needs to be done just once.
		if(simTime().dbl() < period){
		
			yo = yo * correctionFactor(T);  // Initial battery capacity. Joule -> As: As = J / V.
			io = (c * yo);                  // Initializes the Available Charge tank capacity.
			jo = ((1-c) * yo);              // Initializes the Bound Charge tank capacity.
			
			// Adjusting the simulator parameters to work according the T-KiBaM model.
			initialEnergy = io * nV;        // Redefining the initial energy (It is equal to the Available
		                                        // Charge tank capacity).
			remainingEnergy = io * nV;      // The remaining energy is also equal to the initial Available
				                        // Charge tank capacity.			
			Qb = yo;			// Joules -> As.
			y_mAh = Qb * 5/18 * 0.001;      // As -> Ah.
			
			double T_k;
			T_k = T + 273.15;               // Initializes the temperature, from Celsius to Kelvin.
			Expt = arrhenius(0.082728471292994,-2.718140875366010,R,T_k);
			
			i_avg = 0.00375277;             // in A. Approximated initial value according to this application.
							// To-Do: Estimate the average discharge current (i_avg) before
							// the start of the simulation based on the radio consumption and
							// the parameters used in the duty cycle.
		}
		
		// Updating the battery capacity (in mAh).
		y_mAh = yo / 3.6;
	}

	startKibam();
}

// End of KiBaM requirements ********************************************************************/
