//
// Generated file, do not edit! Created by nedtool 4.6 from src/node/communication/mac/mac802154Around/Basic802154AroundPacket.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "Basic802154AroundPacket_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

EXECUTE_ON_STARTUP(
    cEnum *e = cEnum::find("Mac802154Packet_type");
    if (!e) enums.getInstance()->add(e = new cEnum("Mac802154Packet_type"));
    e->insert(MAC_802154_BEACON_PACKET, "MAC_802154_BEACON_PACKET");
    e->insert(MAC_802154_ASSOCIATE_PACKET, "MAC_802154_ASSOCIATE_PACKET");
    e->insert(MAC_802154_DATA_PACKET, "MAC_802154_DATA_PACKET");
    e->insert(MAC_802154_ACK_PACKET, "MAC_802154_ACK_PACKET");
    e->insert(MAC_802154_GTS_REQUEST_PACKET, "MAC_802154_GTS_REQUEST_PACKET");
    e->insert(MAC_802154_FORMATION_PACKET, "MAC_802154_FORMATION_PACKET");
    e->insert(MAC_802154_CCH_PACKET, "MAC_802154_CCH_PACKET");
    e->insert(MAC_802154_COLLISIONDOMAIN_PACKET, "MAC_802154_COLLISIONDOMAIN_PACKET");
    e->insert(MAC_802154_BEACONSCHEDULE_PACKET, "MAC_802154_BEACONSCHEDULE_PACKET");
    e->insert(MAC_802154_CH_RESPONSE_PACKET, "MAC_802154_CH_RESPONSE_PACKET");
    e->insert(MAC_802154_ADDRESSING_REQUEST_PACKET, "MAC_802154_ADDRESSING_REQUEST_PACKET");
    e->insert(MAC_802154_ADDRESSING_RESPONSE_PACKET, "MAC_802154_ADDRESSING_RESPONSE_PACKET");
    e->insert(MAC_802154_ADDRESSING_ASSIGNMENT_PACKET, "MAC_802154_ADDRESSING_ASSIGNMENT_PACKET");
    e->insert(MAC_802154_RATE_ADJUSTMENT_PACKET, "MAC_802154_RATE_ADJUSTMENT_PACKET");
    e->insert(MAC_802154_DATA_REQUEST_PACKET, "MAC_802154_DATA_REQUEST_PACKET");
    e->insert(MAC_802154_AROUND_CONFIG_PACKET, "MAC_802154_AROUND_CONFIG_PACKET");
    e->insert(MAC_802154_AROUND_CONFIG_ACK_PACKET, "MAC_802154_AROUND_CONFIG_ACK_PACKET");
    e->insert(MAC_802154_AROUND_AUTHORIZ_PACKET, "MAC_802154_AROUND_AUTHORIZ_PACKET");
    e->insert(MAC_802154_AGAINCCH_PACKET, "MAC_802154_AGAINCCH_PACKET");
    e->insert(MAC_802154_BEGINBEACON_PACKET, "MAC_802154_BEGINBEACON_PACKET");
    e->insert(MAC_802154_AROUND_PACKET, "MAC_802154_AROUND_PACKET");
    e->insert(MAC_802154_AROUND_ACK_PACKET, "MAC_802154_AROUND_ACK_PACKET");
    e->insert(MAC_802154_CANCEL_AROUND_PACKET, "MAC_802154_CANCEL_AROUND_PACKET");
);

Basic802154AroundGTSspec::Basic802154AroundGTSspec()
{
    owner = 0;
    start = 0;
    length = 0;
}

void doPacking(cCommBuffer *b, Basic802154AroundGTSspec& a)
{
    doPacking(b,a.owner);
    doPacking(b,a.start);
    doPacking(b,a.length);
}

void doUnpacking(cCommBuffer *b, Basic802154AroundGTSspec& a)
{
    doUnpacking(b,a.owner);
    doUnpacking(b,a.start);
    doUnpacking(b,a.length);
}

class Basic802154AroundGTSspecDescriptor : public cClassDescriptor
{
  public:
    Basic802154AroundGTSspecDescriptor();
    virtual ~Basic802154AroundGTSspecDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(Basic802154AroundGTSspecDescriptor);

Basic802154AroundGTSspecDescriptor::Basic802154AroundGTSspecDescriptor() : cClassDescriptor("Basic802154AroundGTSspec", "")
{
}

Basic802154AroundGTSspecDescriptor::~Basic802154AroundGTSspecDescriptor()
{
}

bool Basic802154AroundGTSspecDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<Basic802154AroundGTSspec *>(obj)!=NULL;
}

const char *Basic802154AroundGTSspecDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int Basic802154AroundGTSspecDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 3+basedesc->getFieldCount(object) : 3;
}

unsigned int Basic802154AroundGTSspecDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<3) ? fieldTypeFlags[field] : 0;
}

const char *Basic802154AroundGTSspecDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "owner",
        "start",
        "length",
    };
    return (field>=0 && field<3) ? fieldNames[field] : NULL;
}

int Basic802154AroundGTSspecDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='o' && strcmp(fieldName, "owner")==0) return base+0;
    if (fieldName[0]=='s' && strcmp(fieldName, "start")==0) return base+1;
    if (fieldName[0]=='l' && strcmp(fieldName, "length")==0) return base+2;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *Basic802154AroundGTSspecDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "int",
        "int",
    };
    return (field>=0 && field<3) ? fieldTypeStrings[field] : NULL;
}

const char *Basic802154AroundGTSspecDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int Basic802154AroundGTSspecDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    Basic802154AroundGTSspec *pp = (Basic802154AroundGTSspec *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string Basic802154AroundGTSspecDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    Basic802154AroundGTSspec *pp = (Basic802154AroundGTSspec *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->owner);
        case 1: return long2string(pp->start);
        case 2: return long2string(pp->length);
        default: return "";
    }
}

bool Basic802154AroundGTSspecDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    Basic802154AroundGTSspec *pp = (Basic802154AroundGTSspec *)object; (void)pp;
    switch (field) {
        case 0: pp->owner = string2long(value); return true;
        case 1: pp->start = string2long(value); return true;
        case 2: pp->length = string2long(value); return true;
        default: return false;
    }
}

const char *Basic802154AroundGTSspecDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    };
}

void *Basic802154AroundGTSspecDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    Basic802154AroundGTSspec *pp = (Basic802154AroundGTSspec *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}

Register_Class(Basic802154AroundPacket);

Basic802154AroundPacket::Basic802154AroundPacket(const char *name, int kind) : ::MacPacket(name,kind)
{
    this->Mac802154AroundPacketType_var = 0;
    this->PANid_var = 0;
    this->srcID_var = 0;
    this->dstID_var = 0;
    this->seqNum_var = 0;
    this->beaconOrder_var = 0;
    this->superframeOrder_var = 0;
    this->BSN_var = 0;
    this->CAPlength_var = 0;
    this->GTSlength_var = 0;
    GTSlist_arraysize = 0;
    this->GTSlist_var = 0;
    this->numAddrPending_var = 0;
    AddrList_arraysize = 0;
    this->AddrList_var = 0;
    this->formBSN_var = 0;
    this->hops_var = 0;
    this->ttl_var = 0;
    this->depth_var = 0;
    this->newCH_var = 0;
    this->isCH_var = 0;
    this->startTime_var = 0;
    this->position_var = 0;
    this->childrenCont_var = 0;
    this->startAddressBlock_var = 0;
    this->endAddressBlock_var = 0;
    this->rate_var = 0;
    this->associationAllow_var = 0;
    this->Sink_var = 0;
    this->Source_var = 0;
    this->Destination_var = 0;
    this->flowID_var = 0;
    this->offRX_var = 0;
    this->offTX_var = 0;
    this->duration_var = 0;
}

Basic802154AroundPacket::Basic802154AroundPacket(const Basic802154AroundPacket& other) : ::MacPacket(other)
{
    GTSlist_arraysize = 0;
    this->GTSlist_var = 0;
    AddrList_arraysize = 0;
    this->AddrList_var = 0;
    copy(other);
}

Basic802154AroundPacket::~Basic802154AroundPacket()
{
    delete [] GTSlist_var;
    delete [] AddrList_var;
}

Basic802154AroundPacket& Basic802154AroundPacket::operator=(const Basic802154AroundPacket& other)
{
    if (this==&other) return *this;
    ::MacPacket::operator=(other);
    copy(other);
    return *this;
}

void Basic802154AroundPacket::copy(const Basic802154AroundPacket& other)
{
    this->Mac802154AroundPacketType_var = other.Mac802154AroundPacketType_var;
    this->PANid_var = other.PANid_var;
    this->srcID_var = other.srcID_var;
    this->dstID_var = other.dstID_var;
    this->seqNum_var = other.seqNum_var;
    this->beaconOrder_var = other.beaconOrder_var;
    this->superframeOrder_var = other.superframeOrder_var;
    this->BSN_var = other.BSN_var;
    this->CAPlength_var = other.CAPlength_var;
    this->GTSlength_var = other.GTSlength_var;
    delete [] this->GTSlist_var;
    this->GTSlist_var = (other.GTSlist_arraysize==0) ? NULL : new Basic802154AroundGTSspec[other.GTSlist_arraysize];
    GTSlist_arraysize = other.GTSlist_arraysize;
    for (unsigned int i=0; i<GTSlist_arraysize; i++)
        this->GTSlist_var[i] = other.GTSlist_var[i];
    this->numAddrPending_var = other.numAddrPending_var;
    delete [] this->AddrList_var;
    this->AddrList_var = (other.AddrList_arraysize==0) ? NULL : new int[other.AddrList_arraysize];
    AddrList_arraysize = other.AddrList_arraysize;
    for (unsigned int i=0; i<AddrList_arraysize; i++)
        this->AddrList_var[i] = other.AddrList_var[i];
    this->formBSN_var = other.formBSN_var;
    this->hops_var = other.hops_var;
    this->ttl_var = other.ttl_var;
    this->depth_var = other.depth_var;
    this->newCH_var = other.newCH_var;
    this->isCH_var = other.isCH_var;
    this->startTime_var = other.startTime_var;
    this->position_var = other.position_var;
    this->childrenCont_var = other.childrenCont_var;
    this->startAddressBlock_var = other.startAddressBlock_var;
    this->endAddressBlock_var = other.endAddressBlock_var;
    this->rate_var = other.rate_var;
    this->associationAllow_var = other.associationAllow_var;
    this->Sink_var = other.Sink_var;
    this->Source_var = other.Source_var;
    this->Destination_var = other.Destination_var;
    this->flowID_var = other.flowID_var;
    this->offRX_var = other.offRX_var;
    this->offTX_var = other.offTX_var;
    this->duration_var = other.duration_var;
}

void Basic802154AroundPacket::parsimPack(cCommBuffer *b)
{
    ::MacPacket::parsimPack(b);
    doPacking(b,this->Mac802154AroundPacketType_var);
    doPacking(b,this->PANid_var);
    doPacking(b,this->srcID_var);
    doPacking(b,this->dstID_var);
    doPacking(b,this->seqNum_var);
    doPacking(b,this->beaconOrder_var);
    doPacking(b,this->superframeOrder_var);
    doPacking(b,this->BSN_var);
    doPacking(b,this->CAPlength_var);
    doPacking(b,this->GTSlength_var);
    b->pack(GTSlist_arraysize);
    doPacking(b,this->GTSlist_var,GTSlist_arraysize);
    doPacking(b,this->numAddrPending_var);
    b->pack(AddrList_arraysize);
    doPacking(b,this->AddrList_var,AddrList_arraysize);
    doPacking(b,this->formBSN_var);
    doPacking(b,this->hops_var);
    doPacking(b,this->ttl_var);
    doPacking(b,this->depth_var);
    doPacking(b,this->newCH_var);
    doPacking(b,this->isCH_var);
    doPacking(b,this->startTime_var);
    doPacking(b,this->position_var);
    doPacking(b,this->childrenCont_var);
    doPacking(b,this->startAddressBlock_var);
    doPacking(b,this->endAddressBlock_var);
    doPacking(b,this->rate_var);
    doPacking(b,this->associationAllow_var);
    doPacking(b,this->Sink_var);
    doPacking(b,this->Source_var);
    doPacking(b,this->Destination_var);
    doPacking(b,this->flowID_var);
    doPacking(b,this->offRX_var);
    doPacking(b,this->offTX_var);
    doPacking(b,this->duration_var);
}

void Basic802154AroundPacket::parsimUnpack(cCommBuffer *b)
{
    ::MacPacket::parsimUnpack(b);
    doUnpacking(b,this->Mac802154AroundPacketType_var);
    doUnpacking(b,this->PANid_var);
    doUnpacking(b,this->srcID_var);
    doUnpacking(b,this->dstID_var);
    doUnpacking(b,this->seqNum_var);
    doUnpacking(b,this->beaconOrder_var);
    doUnpacking(b,this->superframeOrder_var);
    doUnpacking(b,this->BSN_var);
    doUnpacking(b,this->CAPlength_var);
    doUnpacking(b,this->GTSlength_var);
    delete [] this->GTSlist_var;
    b->unpack(GTSlist_arraysize);
    if (GTSlist_arraysize==0) {
        this->GTSlist_var = 0;
    } else {
        this->GTSlist_var = new Basic802154AroundGTSspec[GTSlist_arraysize];
        doUnpacking(b,this->GTSlist_var,GTSlist_arraysize);
    }
    doUnpacking(b,this->numAddrPending_var);
    delete [] this->AddrList_var;
    b->unpack(AddrList_arraysize);
    if (AddrList_arraysize==0) {
        this->AddrList_var = 0;
    } else {
        this->AddrList_var = new int[AddrList_arraysize];
        doUnpacking(b,this->AddrList_var,AddrList_arraysize);
    }
    doUnpacking(b,this->formBSN_var);
    doUnpacking(b,this->hops_var);
    doUnpacking(b,this->ttl_var);
    doUnpacking(b,this->depth_var);
    doUnpacking(b,this->newCH_var);
    doUnpacking(b,this->isCH_var);
    doUnpacking(b,this->startTime_var);
    doUnpacking(b,this->position_var);
    doUnpacking(b,this->childrenCont_var);
    doUnpacking(b,this->startAddressBlock_var);
    doUnpacking(b,this->endAddressBlock_var);
    doUnpacking(b,this->rate_var);
    doUnpacking(b,this->associationAllow_var);
    doUnpacking(b,this->Sink_var);
    doUnpacking(b,this->Source_var);
    doUnpacking(b,this->Destination_var);
    doUnpacking(b,this->flowID_var);
    doUnpacking(b,this->offRX_var);
    doUnpacking(b,this->offTX_var);
    doUnpacking(b,this->duration_var);
}

int Basic802154AroundPacket::getMac802154AroundPacketType() const
{
    return Mac802154AroundPacketType_var;
}

void Basic802154AroundPacket::setMac802154AroundPacketType(int Mac802154AroundPacketType)
{
    this->Mac802154AroundPacketType_var = Mac802154AroundPacketType;
}

int Basic802154AroundPacket::getPANid() const
{
    return PANid_var;
}

void Basic802154AroundPacket::setPANid(int PANid)
{
    this->PANid_var = PANid;
}

int Basic802154AroundPacket::getSrcID() const
{
    return srcID_var;
}

void Basic802154AroundPacket::setSrcID(int srcID)
{
    this->srcID_var = srcID;
}

int Basic802154AroundPacket::getDstID() const
{
    return dstID_var;
}

void Basic802154AroundPacket::setDstID(int dstID)
{
    this->dstID_var = dstID;
}

int Basic802154AroundPacket::getSeqNum() const
{
    return seqNum_var;
}

void Basic802154AroundPacket::setSeqNum(int seqNum)
{
    this->seqNum_var = seqNum;
}

int Basic802154AroundPacket::getBeaconOrder() const
{
    return beaconOrder_var;
}

void Basic802154AroundPacket::setBeaconOrder(int beaconOrder)
{
    this->beaconOrder_var = beaconOrder;
}

int Basic802154AroundPacket::getSuperframeOrder() const
{
    return superframeOrder_var;
}

void Basic802154AroundPacket::setSuperframeOrder(int superframeOrder)
{
    this->superframeOrder_var = superframeOrder;
}

int Basic802154AroundPacket::getBSN() const
{
    return BSN_var;
}

void Basic802154AroundPacket::setBSN(int BSN)
{
    this->BSN_var = BSN;
}

int Basic802154AroundPacket::getCAPlength() const
{
    return CAPlength_var;
}

void Basic802154AroundPacket::setCAPlength(int CAPlength)
{
    this->CAPlength_var = CAPlength;
}

int Basic802154AroundPacket::getGTSlength() const
{
    return GTSlength_var;
}

void Basic802154AroundPacket::setGTSlength(int GTSlength)
{
    this->GTSlength_var = GTSlength;
}

void Basic802154AroundPacket::setGTSlistArraySize(unsigned int size)
{
    Basic802154AroundGTSspec *GTSlist_var2 = (size==0) ? NULL : new Basic802154AroundGTSspec[size];
    unsigned int sz = GTSlist_arraysize < size ? GTSlist_arraysize : size;
    for (unsigned int i=0; i<sz; i++)
        GTSlist_var2[i] = this->GTSlist_var[i];
    GTSlist_arraysize = size;
    delete [] this->GTSlist_var;
    this->GTSlist_var = GTSlist_var2;
}

unsigned int Basic802154AroundPacket::getGTSlistArraySize() const
{
    return GTSlist_arraysize;
}

Basic802154AroundGTSspec& Basic802154AroundPacket::getGTSlist(unsigned int k)
{
    if (k>=GTSlist_arraysize) throw cRuntimeError("Array of size %d indexed by %d", GTSlist_arraysize, k);
    return GTSlist_var[k];
}

void Basic802154AroundPacket::setGTSlist(unsigned int k, const Basic802154AroundGTSspec& GTSlist)
{
    if (k>=GTSlist_arraysize) throw cRuntimeError("Array of size %d indexed by %d", GTSlist_arraysize, k);
    this->GTSlist_var[k] = GTSlist;
}

int Basic802154AroundPacket::getNumAddrPending() const
{
    return numAddrPending_var;
}

void Basic802154AroundPacket::setNumAddrPending(int numAddrPending)
{
    this->numAddrPending_var = numAddrPending;
}

void Basic802154AroundPacket::setAddrListArraySize(unsigned int size)
{
    int *AddrList_var2 = (size==0) ? NULL : new int[size];
    unsigned int sz = AddrList_arraysize < size ? AddrList_arraysize : size;
    for (unsigned int i=0; i<sz; i++)
        AddrList_var2[i] = this->AddrList_var[i];
    for (unsigned int i=sz; i<size; i++)
        AddrList_var2[i] = 0;
    AddrList_arraysize = size;
    delete [] this->AddrList_var;
    this->AddrList_var = AddrList_var2;
}

unsigned int Basic802154AroundPacket::getAddrListArraySize() const
{
    return AddrList_arraysize;
}

int Basic802154AroundPacket::getAddrList(unsigned int k) const
{
    if (k>=AddrList_arraysize) throw cRuntimeError("Array of size %d indexed by %d", AddrList_arraysize, k);
    return AddrList_var[k];
}

void Basic802154AroundPacket::setAddrList(unsigned int k, int AddrList)
{
    if (k>=AddrList_arraysize) throw cRuntimeError("Array of size %d indexed by %d", AddrList_arraysize, k);
    this->AddrList_var[k] = AddrList;
}

int Basic802154AroundPacket::getFormBSN() const
{
    return formBSN_var;
}

void Basic802154AroundPacket::setFormBSN(int formBSN)
{
    this->formBSN_var = formBSN;
}

int Basic802154AroundPacket::getHops() const
{
    return hops_var;
}

void Basic802154AroundPacket::setHops(int hops)
{
    this->hops_var = hops;
}

int Basic802154AroundPacket::getTtl() const
{
    return ttl_var;
}

void Basic802154AroundPacket::setTtl(int ttl)
{
    this->ttl_var = ttl;
}

int Basic802154AroundPacket::getDepth() const
{
    return depth_var;
}

void Basic802154AroundPacket::setDepth(int depth)
{
    this->depth_var = depth;
}

bool Basic802154AroundPacket::getNewCH() const
{
    return newCH_var;
}

void Basic802154AroundPacket::setNewCH(bool newCH)
{
    this->newCH_var = newCH;
}

bool Basic802154AroundPacket::getIsCH() const
{
    return isCH_var;
}

void Basic802154AroundPacket::setIsCH(bool isCH)
{
    this->isCH_var = isCH;
}

double Basic802154AroundPacket::getStartTime() const
{
    return startTime_var;
}

void Basic802154AroundPacket::setStartTime(double startTime)
{
    this->startTime_var = startTime;
}

int Basic802154AroundPacket::getPosition() const
{
    return position_var;
}

void Basic802154AroundPacket::setPosition(int position)
{
    this->position_var = position;
}

int Basic802154AroundPacket::getChildrenCont() const
{
    return childrenCont_var;
}

void Basic802154AroundPacket::setChildrenCont(int childrenCont)
{
    this->childrenCont_var = childrenCont;
}

int Basic802154AroundPacket::getStartAddressBlock() const
{
    return startAddressBlock_var;
}

void Basic802154AroundPacket::setStartAddressBlock(int startAddressBlock)
{
    this->startAddressBlock_var = startAddressBlock;
}

int Basic802154AroundPacket::getEndAddressBlock() const
{
    return endAddressBlock_var;
}

void Basic802154AroundPacket::setEndAddressBlock(int endAddressBlock)
{
    this->endAddressBlock_var = endAddressBlock;
}

double Basic802154AroundPacket::getRate() const
{
    return rate_var;
}

void Basic802154AroundPacket::setRate(double rate)
{
    this->rate_var = rate;
}

bool Basic802154AroundPacket::getAssociationAllow() const
{
    return associationAllow_var;
}

void Basic802154AroundPacket::setAssociationAllow(bool associationAllow)
{
    this->associationAllow_var = associationAllow;
}

int Basic802154AroundPacket::getSink() const
{
    return Sink_var;
}

void Basic802154AroundPacket::setSink(int Sink)
{
    this->Sink_var = Sink;
}

int Basic802154AroundPacket::getSource() const
{
    return Source_var;
}

void Basic802154AroundPacket::setSource(int Source)
{
    this->Source_var = Source;
}

int Basic802154AroundPacket::getDestination() const
{
    return Destination_var;
}

void Basic802154AroundPacket::setDestination(int Destination)
{
    this->Destination_var = Destination;
}

int Basic802154AroundPacket::getFlowID() const
{
    return flowID_var;
}

void Basic802154AroundPacket::setFlowID(int flowID)
{
    this->flowID_var = flowID;
}

int Basic802154AroundPacket::getOffRX() const
{
    return offRX_var;
}

void Basic802154AroundPacket::setOffRX(int offRX)
{
    this->offRX_var = offRX;
}

int Basic802154AroundPacket::getOffTX() const
{
    return offTX_var;
}

void Basic802154AroundPacket::setOffTX(int offTX)
{
    this->offTX_var = offTX;
}

int Basic802154AroundPacket::getDuration() const
{
    return duration_var;
}

void Basic802154AroundPacket::setDuration(int duration)
{
    this->duration_var = duration;
}

class Basic802154AroundPacketDescriptor : public cClassDescriptor
{
  public:
    Basic802154AroundPacketDescriptor();
    virtual ~Basic802154AroundPacketDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(Basic802154AroundPacketDescriptor);

Basic802154AroundPacketDescriptor::Basic802154AroundPacketDescriptor() : cClassDescriptor("Basic802154AroundPacket", "MacPacket")
{
}

Basic802154AroundPacketDescriptor::~Basic802154AroundPacketDescriptor()
{
}

bool Basic802154AroundPacketDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<Basic802154AroundPacket *>(obj)!=NULL;
}

const char *Basic802154AroundPacketDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int Basic802154AroundPacketDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 33+basedesc->getFieldCount(object) : 33;
}

unsigned int Basic802154AroundPacketDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISARRAY | FD_ISCOMPOUND,
        FD_ISEDITABLE,
        FD_ISARRAY | FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<33) ? fieldTypeFlags[field] : 0;
}

const char *Basic802154AroundPacketDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "Mac802154AroundPacketType",
        "PANid",
        "srcID",
        "dstID",
        "seqNum",
        "beaconOrder",
        "superframeOrder",
        "BSN",
        "CAPlength",
        "GTSlength",
        "GTSlist",
        "numAddrPending",
        "AddrList",
        "formBSN",
        "hops",
        "ttl",
        "depth",
        "newCH",
        "isCH",
        "startTime",
        "position",
        "childrenCont",
        "startAddressBlock",
        "endAddressBlock",
        "rate",
        "associationAllow",
        "Sink",
        "Source",
        "Destination",
        "flowID",
        "offRX",
        "offTX",
        "duration",
    };
    return (field>=0 && field<33) ? fieldNames[field] : NULL;
}

int Basic802154AroundPacketDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='M' && strcmp(fieldName, "Mac802154AroundPacketType")==0) return base+0;
    if (fieldName[0]=='P' && strcmp(fieldName, "PANid")==0) return base+1;
    if (fieldName[0]=='s' && strcmp(fieldName, "srcID")==0) return base+2;
    if (fieldName[0]=='d' && strcmp(fieldName, "dstID")==0) return base+3;
    if (fieldName[0]=='s' && strcmp(fieldName, "seqNum")==0) return base+4;
    if (fieldName[0]=='b' && strcmp(fieldName, "beaconOrder")==0) return base+5;
    if (fieldName[0]=='s' && strcmp(fieldName, "superframeOrder")==0) return base+6;
    if (fieldName[0]=='B' && strcmp(fieldName, "BSN")==0) return base+7;
    if (fieldName[0]=='C' && strcmp(fieldName, "CAPlength")==0) return base+8;
    if (fieldName[0]=='G' && strcmp(fieldName, "GTSlength")==0) return base+9;
    if (fieldName[0]=='G' && strcmp(fieldName, "GTSlist")==0) return base+10;
    if (fieldName[0]=='n' && strcmp(fieldName, "numAddrPending")==0) return base+11;
    if (fieldName[0]=='A' && strcmp(fieldName, "AddrList")==0) return base+12;
    if (fieldName[0]=='f' && strcmp(fieldName, "formBSN")==0) return base+13;
    if (fieldName[0]=='h' && strcmp(fieldName, "hops")==0) return base+14;
    if (fieldName[0]=='t' && strcmp(fieldName, "ttl")==0) return base+15;
    if (fieldName[0]=='d' && strcmp(fieldName, "depth")==0) return base+16;
    if (fieldName[0]=='n' && strcmp(fieldName, "newCH")==0) return base+17;
    if (fieldName[0]=='i' && strcmp(fieldName, "isCH")==0) return base+18;
    if (fieldName[0]=='s' && strcmp(fieldName, "startTime")==0) return base+19;
    if (fieldName[0]=='p' && strcmp(fieldName, "position")==0) return base+20;
    if (fieldName[0]=='c' && strcmp(fieldName, "childrenCont")==0) return base+21;
    if (fieldName[0]=='s' && strcmp(fieldName, "startAddressBlock")==0) return base+22;
    if (fieldName[0]=='e' && strcmp(fieldName, "endAddressBlock")==0) return base+23;
    if (fieldName[0]=='r' && strcmp(fieldName, "rate")==0) return base+24;
    if (fieldName[0]=='a' && strcmp(fieldName, "associationAllow")==0) return base+25;
    if (fieldName[0]=='S' && strcmp(fieldName, "Sink")==0) return base+26;
    if (fieldName[0]=='S' && strcmp(fieldName, "Source")==0) return base+27;
    if (fieldName[0]=='D' && strcmp(fieldName, "Destination")==0) return base+28;
    if (fieldName[0]=='f' && strcmp(fieldName, "flowID")==0) return base+29;
    if (fieldName[0]=='o' && strcmp(fieldName, "offRX")==0) return base+30;
    if (fieldName[0]=='o' && strcmp(fieldName, "offTX")==0) return base+31;
    if (fieldName[0]=='d' && strcmp(fieldName, "duration")==0) return base+32;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *Basic802154AroundPacketDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "int",
        "int",
        "int",
        "int",
        "int",
        "int",
        "int",
        "int",
        "int",
        "Basic802154AroundGTSspec",
        "int",
        "int",
        "int",
        "int",
        "int",
        "int",
        "bool",
        "bool",
        "double",
        "int",
        "int",
        "int",
        "int",
        "double",
        "bool",
        "int",
        "int",
        "int",
        "int",
        "int",
        "int",
        "int",
    };
    return (field>=0 && field<33) ? fieldTypeStrings[field] : NULL;
}

const char *Basic802154AroundPacketDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 0:
            if (!strcmp(propertyname,"enum")) return "Mac802154Packet_type";
            return NULL;
        default: return NULL;
    }
}

int Basic802154AroundPacketDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    Basic802154AroundPacket *pp = (Basic802154AroundPacket *)object; (void)pp;
    switch (field) {
        case 10: return pp->getGTSlistArraySize();
        case 12: return pp->getAddrListArraySize();
        default: return 0;
    }
}

std::string Basic802154AroundPacketDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    Basic802154AroundPacket *pp = (Basic802154AroundPacket *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getMac802154AroundPacketType());
        case 1: return long2string(pp->getPANid());
        case 2: return long2string(pp->getSrcID());
        case 3: return long2string(pp->getDstID());
        case 4: return long2string(pp->getSeqNum());
        case 5: return long2string(pp->getBeaconOrder());
        case 6: return long2string(pp->getSuperframeOrder());
        case 7: return long2string(pp->getBSN());
        case 8: return long2string(pp->getCAPlength());
        case 9: return long2string(pp->getGTSlength());
        case 10: {std::stringstream out; out << pp->getGTSlist(i); return out.str();}
        case 11: return long2string(pp->getNumAddrPending());
        case 12: return long2string(pp->getAddrList(i));
        case 13: return long2string(pp->getFormBSN());
        case 14: return long2string(pp->getHops());
        case 15: return long2string(pp->getTtl());
        case 16: return long2string(pp->getDepth());
        case 17: return bool2string(pp->getNewCH());
        case 18: return bool2string(pp->getIsCH());
        case 19: return double2string(pp->getStartTime());
        case 20: return long2string(pp->getPosition());
        case 21: return long2string(pp->getChildrenCont());
        case 22: return long2string(pp->getStartAddressBlock());
        case 23: return long2string(pp->getEndAddressBlock());
        case 24: return double2string(pp->getRate());
        case 25: return bool2string(pp->getAssociationAllow());
        case 26: return long2string(pp->getSink());
        case 27: return long2string(pp->getSource());
        case 28: return long2string(pp->getDestination());
        case 29: return long2string(pp->getFlowID());
        case 30: return long2string(pp->getOffRX());
        case 31: return long2string(pp->getOffTX());
        case 32: return long2string(pp->getDuration());
        default: return "";
    }
}

bool Basic802154AroundPacketDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    Basic802154AroundPacket *pp = (Basic802154AroundPacket *)object; (void)pp;
    switch (field) {
        case 0: pp->setMac802154AroundPacketType(string2long(value)); return true;
        case 1: pp->setPANid(string2long(value)); return true;
        case 2: pp->setSrcID(string2long(value)); return true;
        case 3: pp->setDstID(string2long(value)); return true;
        case 4: pp->setSeqNum(string2long(value)); return true;
        case 5: pp->setBeaconOrder(string2long(value)); return true;
        case 6: pp->setSuperframeOrder(string2long(value)); return true;
        case 7: pp->setBSN(string2long(value)); return true;
        case 8: pp->setCAPlength(string2long(value)); return true;
        case 9: pp->setGTSlength(string2long(value)); return true;
        case 11: pp->setNumAddrPending(string2long(value)); return true;
        case 12: pp->setAddrList(i,string2long(value)); return true;
        case 13: pp->setFormBSN(string2long(value)); return true;
        case 14: pp->setHops(string2long(value)); return true;
        case 15: pp->setTtl(string2long(value)); return true;
        case 16: pp->setDepth(string2long(value)); return true;
        case 17: pp->setNewCH(string2bool(value)); return true;
        case 18: pp->setIsCH(string2bool(value)); return true;
        case 19: pp->setStartTime(string2double(value)); return true;
        case 20: pp->setPosition(string2long(value)); return true;
        case 21: pp->setChildrenCont(string2long(value)); return true;
        case 22: pp->setStartAddressBlock(string2long(value)); return true;
        case 23: pp->setEndAddressBlock(string2long(value)); return true;
        case 24: pp->setRate(string2double(value)); return true;
        case 25: pp->setAssociationAllow(string2bool(value)); return true;
        case 26: pp->setSink(string2long(value)); return true;
        case 27: pp->setSource(string2long(value)); return true;
        case 28: pp->setDestination(string2long(value)); return true;
        case 29: pp->setFlowID(string2long(value)); return true;
        case 30: pp->setOffRX(string2long(value)); return true;
        case 31: pp->setOffTX(string2long(value)); return true;
        case 32: pp->setDuration(string2long(value)); return true;
        default: return false;
    }
}

const char *Basic802154AroundPacketDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 10: return opp_typename(typeid(Basic802154AroundGTSspec));
        default: return NULL;
    };
}

void *Basic802154AroundPacketDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    Basic802154AroundPacket *pp = (Basic802154AroundPacket *)object; (void)pp;
    switch (field) {
        case 10: return (void *)(&pp->getGTSlist(i)); break;
        default: return NULL;
    }
}


