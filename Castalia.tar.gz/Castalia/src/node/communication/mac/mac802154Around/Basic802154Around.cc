//****************************************************************************
//*  Copyright (c) Faculty of Engineering, University of Porto, Portugal     *
//*  All rights reserved                                                     *
//*                                                                          *
//*  Module: Mac ARounD Approach for Castalia Simulator                      *
//*  File: Basic802154Around.cc                                              *
//*  Date: 2015-03-05                                                        *
//*  Version:  0.1                                                           *
//*  Author(s): Erico Leão <ericoleao@gmail.com>                             *
//****************************************************************************/

#include "Basic802154Around.h"
#include "VirtualMobilityManager.h"
//#include "AroundControlMessage_m.h"



// This module is virtual and can not be used directly
Define_Module(Basic802154Around);


// Função de Inicialização da Simulação
void Basic802154Around::startup(){
    
    //Inicializando uma nova simulação
    if(SELF_MAC_ADDRESS == 0)
        trace() << "NEW SIMULATION!";  // around - debug
    
    
    // Nicolas, a principio eu defino um tempo máximo para associações. Durante esse tempo, a cluster-tree pode-se formar.
    // Entretanto, seria interessante a gente definir uma formação com base nos parâmetros ZigBee:
    // - número máximo de filhos
    // - número máximo de cluster-heads filhos
    // - profundidade máxima
    
    maxformationtime = par("maxformationtime");  //tempo máximo para o procedimento de formação de clusters
    //Definindo um temporizador de tempo máximo de formação. Após esse temporizador esgotar, todos os
    //timer ativos serão cancelados e a rede passará para fase de definição do domínio de colisão.
    setTimer(FORMATION_TIME, maxformationtime - getClock()); // fazendo assim, eu defino o tempo que eu quero para formação de clusters
    
    
    //Impressão dos Estados do MAC
    printStateTransitions = par("printStateTransitions");
	if (printStateTransitions) {
		stateDescr[1000] = "MAC_STATE_SETUP";
		stateDescr[1001] = "MAC_STATE_SLEEP";
		stateDescr[1002] = "MAC_STATE_CAP";
		stateDescr[1003] = "MAC_STATE_GTS";
        stateDescr[1004] = "MAC_STATE_FORMATION";
        stateDescr[1005] = "MAC_STATE_CAP_CH";
	}
    
    //É coordenador PAN (Bool) - pega parâmetro do .NED - default (false)
	isPANCoordinator = par("isPANCoordinator");
	//É um nó FFD (bool) - pega parâmetro do .NED - default (false)
    isFFD = par("isFFD");
    
    // Around: provisoriamente, todo mundo é FFD e pode ser um CH
    isFFD = true;
    
	// Tamanho mínimo do CAP (int) - pega parâmetro do .NED - default (440)
	aMinCAPLength = par("aMinCAPLength");

	// Parâmetros que definem o Slot do 802.15.4 - em símbolos
	// aUnitBackoffPeriod (int) - pega parâmetro do .NED - default (20)
    aUnitBackoffPeriod = par("aUnitBackoffPeriod");
	// aBaseSlotduration (int) - pega parâmetro do .NED - default (60)
    aBaseSlotDuration = par("aBaseSlotDuration");
	// aNumSuperframeSlots (int) - pega parâmetro do .NED - default (16)
    aNumSuperframeSlots = par("aNumSuperframeSlots");
	// Tamanho base da duração de superframe (int) = aBaseSlotDuration * aNumSuperframeSlots
    aBaseSuperframeDuration = aBaseSlotDuration * aNumSuperframeSlots;

	// Parâmetros que definem o protocolo CSMA
    // Habilita o modo com beacon (bool) - pega parâmetro do .NED - default (true)
	enableSlottedCSMA = par("enableSlottedCSMA");
	// MacMinBE (int) - pega parâmetro do .NED - default (5) [OBS: default do padrão = 3] [Valores de 0 - maxMacBE]
    macMinBE = par("macMinBE");
	// MacMaxBE (int) - pega parâmetro do .NED - default (7) [Valores de 3 - 8]
    macMaxBE = par("macMaxBE");
	// macMacCSMABackoffs (int) - pega parâmetro do .NED - default (4) [Valores de 0 - 5]
    macMaxCSMABackoffs = par("macMaxCSMABackoffs");
	// macMacFrameRetries (int) - pega parâmetro do .NED - default (2) [OBS: default do padrão = 3] [Valores de 0 - 7]
    macMaxFrameRetries = par("macMaxFrameRetries");
	// (bool) - pega parâmetro do .NED - default (false)
    macBattLifeExt = par("macBattLifeExt");

	// Parâmetros da e dependentes da Camada Física
	// (double) - pega parâmetro do .NED - não tem default
    phyDataRate = par("phyDataRate");
	// (double) - pega parâmetro do .NED - default (0.2) in ms
    phyDelaySleep2Tx = (double)par("phyDelaySleep2Tx") / 1000.0;
	// (double) - pega parâmetro do .NED - default (0.02) in ms
    phyDelayRx2Tx = (double)par("phyDelayRx2Tx") / 1000.0;
	// (double) - pega parâmetro do .NED - default (0.128)
    phyDelayForValidCS = (double)par("phyDelayForValidCS") / 1000.0;
	// (int) - pega parâmetro do .NED - default (6)
    phyLayerOverhead = par("phyFrameOverhead");  //Nao usado no código MAC
	// (int) - pega parâmetro do .NED - não tem default
    phyBitsPerSymbol = par("phyBitsPerSymbol");
	symbolLen = 1 / (phyDataRate * 1000 / phyBitsPerSymbol);
	macAckWaitDuration = symbolLen * aUnitBackoffPeriod +
			phyDelayRx2Tx * 2 + TX_TIME(ACK_PKT_SIZE);

  	
    // Parâmetros de conexão do HUB
	// (double) - pega parâmetro do .NED - default (1)
    guardTime = (double)par("guardTime") / 1000.0;
    // Tentativas que irá causar a perda de sincronização - aMaxLostBeacons (int) - pega parâmetro do .NED - default (4)
	aMaxLostBeacons = par("aMaxLostBeacons");

	// inicialização do MAC Geral
	currentPacket = NULL;
	macState = MAC_STATE_SETUP;
	associatedPAN = -1;
	currentFrameStart = 0;
	GTSstart = 0;
	GTSend = 0;
	CAPend = 0;
	//backgroundSeqNum = 0; //número de sequencia de quadros backgrounds
    seqNum = 0;
    macBSN = 0;
    recMacBSN = 0;
    aroundConfSeqNum = 0;
    aroundSeqNum = 0;

	// Estatísticas para reportar
	lostBeacons = 0;
	sentBeacons = 0;
	recvBeacons = 0;
	packetoverflow = 0;
	desyncTime = 0;
	desyncTimeStart = 0;
	packetBreak.clear();
	declareOutput("pkt TX state breakdown");
    replacedPackets = 0; //pacotes de dados substituídos ao chegar da network
    
    // Around Approach
    maxFormationFrame = par("maxFormationFrame");
    formationFrameCount = 0;
    
    // Around: Variáveis para o cluster-tree
    isCH = false; // Se o nó é Cluster-head
    parentCH = 0; // Não tem CH pai ainda
    hops = par("hops");   //máxima distancia em hops de um nó para o seu CH
    ttl = par("ttl");
    depth = -1;
    nchildren = 0;      //quantidade de filhos de um nó CH
    totalchildren = 0;  // quantidade de filhos acumulados
    formationSeqNum = 0;
    formationTime = par("formationTime");
    nowFormationACK = par("nowFormationACK");
    ackWaitFormation = par("ackWaitFormation");
    fixedPacketRate = par("fixedPacketRate");
    basePacketRate = par("basePacketRate");
    
    
    //ESQUEMA DE ALOCACAO DE SD, Teste de escalonamento
    superframeOrder = par("superframeOrder");     // Superframe Order, caso o esquema de escalonamento seja estático
    beaconOrder = par("beaconOrder");             //Beacon Order
    
    
    beaconInterval = aBaseSuperframeDuration * (1 << beaconOrder);
    superframeDuration = aBaseSuperframeDuration * (1 << superframeOrder);
    
    // Definição do Tamanho do CAP
    CAPlength = aNumSuperframeSlots;
    
    
    declareOutput("PERCA");
    
    
    
    
	// Inicialização do nó Coordenador
	if (isPANCoordinator) {
		// Teste para saber se é nó FFD
        if (!isFFD) {
			opp_error("Only full-function devices (isFFD=true) can be PAN coordinators");
		}

        // Se é um nó FFD, inicializa o nó Coordenador PAN
		associatedPAN = SELF_MAC_ADDRESS;       //associatedPAN é o endereço do nó
		
		//iniciliza Superframe Order e Beacon Order
        // Superframe Order (int) - pega parâmetro do .NED - default (4)
		superframeOrder = par("superframeOrder");     //Superframe Order
		// Beacon Order (int) - pega parâmetro do .NED - default (6)
        beaconOrder = par("beaconOrder");   //Beacon Order
		
        //Combinações inválidas de Superframe e Beacon Order
        if (superframeOrder < 0 || beaconOrder < 0 || beaconOrder > 14
		    || superframeOrder > 14 || beaconOrder < superframeOrder) {
			opp_error("Invalid combination of superframeOrder and beaconOrder parameters. Must be 0 <= superframeOrder <= beaconOrder <= 14");
		}
        
        // Cálculo do Intervalo de Beacon
		beaconInterval = aBaseSuperframeDuration * (1 << beaconOrder);
		// Cálculo do Tamanho do Superframe
        superframeDuration = aBaseSuperframeDuration * (1 << superframeOrder);
		// Definição do Tamanho do CAP
        CAPlength = aNumSuperframeSlots;
        
        // Around: inicialização da profundidade do PAN
        depth = 0;
        
        // Combinações inválidas para o BI e SD
		if (beaconInterval <= 0 || superframeDuration <= 0) {
			opp_error("Invalid parameter combination of aBaseSlotDuration and aNumSuperframeSlots");
		}
        
        
        // Inicializa o TIMER CLUSTER_FORMATION
        setTimer(CLUSTER_FORMATION, 0);	//cluster formation is NOW
        
	}
}



//----------------------------------------------------------------------------------------------------------------------------
//
//  TIMERS
//
//----------------------------------------------------------------------------------------------------------------------------



// Função com Timers
void Basic802154Around::timerFiredCallback(int index)
{
	switch (index) {
		
        // Procedimento de Formação de cluster - CHs enviam "beacon", "convidando" nós para associação
        case CLUSTER_FORMATION: {
            // Sendo um coordenador, cria e broadcast pacote de formação de cluster
            if (((isPANCoordinator) || (isCH))) {
                formationFrameCount++;
                if(formationFrameCount <= maxFormationFrame){
                    formationPacket = new Basic802154AroundPacket("Cluster Formation packet", MAC_LAYER_PACKET);
                    formationPacket->setMac802154AroundPacketType(MAC_802154_FORMATION_PACKET);     // Tipo:  2 bytes
                    formationPacket->setPANid(SELF_MAC_ADDRESS);                                    // PANid: 2 bytes
                    formationPacket->setDstID(BROADCAST_MAC_ADDRESS);                               // DstID: 2 bytes
                    formationPacket->setFormBSN(formationSeqNum);                                   // BO:    2 bytes
                    formationPacket->setDepth(depth);                                               // Depth: 2 bytes
                    
                    formationPacket->setByteLength(FORMATION_PKT_SIZE);
                    
                    //Seta setMacState para MAC_STATE_FORMATION
                    setMacState(MAC_STATE_FORMATION);
                    
                    // Envia o pacote de formação do cluster para o rádio
                    trace() << "Transmitting [Cluster Formation packet] now!!";
                    toRadioLayer(formationPacket);
                    toRadioLayer(createRadioCommand(SET_STATE, TX));
                    setTimer(ATTEMPT_TX, TX_TIME(formationPacket->getByteLength()));
                    formationPacket = NULL;    // define para nulo o formation packet
                    formationSeqNum++;
                    //Atualiza o tempo do início do próximo superframe, iniciado logo abaixo
                    currentFrameStart = getClock() + phyDelayRx2Tx;
                    
                    setTimer(CLUSTER_FORMATION, formationTime);
                    
                } else {
                    //AROUND: Após enviar todos os quadros de formação, ir para seleção de CCH
                    formationSeqNum = 0;
                    //setTimer(CCH_SELECT, 0);
                    //É realmente necessário usar o Timer acima??
                    //Acredito que chamando direto a função selectCCH tenha o mesmo efeito
                    selectCCH();
                }
            
            }
            break;
        }
        
        // Seleção de Candidatos a Cluster-Heads - CCHs
        case CCH_SELECT: {
            //trace() << "XX " << SELF_MAC_ADDRESS << " associatedPAN " << associatedPAN;  // Around - Debug
            
            if ((isPANCoordinator) || (isCH)) {
                selectCCH();
            }
            else {
                //  trace() << "ACORDANDO!!";  // Around - Debug
                toRadioLayer(createRadioCommand(SET_STATE, RX));
            
                if(associatedPAN != -1){
                    //trace() << "Associado";  // Around - Debug
                }
                else{
                    //trace() << "NAO-Associado";  // Around - Debug
                }
            }
      
            break;
        }
            
        // Definição do Domínio de Colisão e estruturas para o algoritmo ARounD
        case FORMATION_TIME: {
            trace() << "ENTREI NO FORMATION TIME " << SELF_MAC_ADDRESS << " com AssociatedPAN: " << associatedPAN;  //around - debug
            
            //trace() << "OO formation " << getTimer(CLUSTER_FORMATION);  //around - debug
            //trace() << "OO select " << getTimer(CCH_SELECT);  //around - debug
            
            //Cancela o Timer de formação de cluster
            if(getTimer(CLUSTER_FORMATION) != -1){
///                trace() << "Existe Timer Cluster_Formation de " << SELF_MAC_ADDRESS; //around - debug
                cancelTimer(CLUSTER_FORMATION);
                //Caso tenha sido selecionado como CCH, mas não teve "tempo" de associar nenhum filho
                //então deixa de ser CH
                if(nchildren == 0){
///                    trace() << "DESALOCANDO POR NAO ENTRAR NA FORMACAO DE CLUSTER " << SELF_MAC_ADDRESS; //around - debug
                    isCH = false;
                    //setTimer(SLEEP_START,0); //vai dormir. Cancelado, por enquanto
                }
               
            }
            
            if(getTimer(CCH_SELECT) != -1)
                cancelTimer(CCH_SELECT);
            
            //trace() << "OO formation " << getTimer(CLUSTER_FORMATION);  //around - debug
            //trace() << "OO select " << getTimer(CCH_SELECT);  //around - debug
            
            toRadioLayer(createRadioCommand(SET_STATE, RX));
//            setTimer(COLLISION_DOMAIN, maxFormationFrame * formationTime + ((double)SELF_MAC_ADDRESS)/100);
            break;
        }

            
        // Início de um novo superframe
		case FRAME_START: {
			trace() << "ENTREI NO FRAME_START " << SELF_MAC_ADDRESS;  //around - debug
            
            if ((isPANCoordinator) || (isCH)) {	// Sendo um coordenador, cria e broadcast pacote beacon
///                trace() << "BEACON agora!";  // Around - Debug
                //cria o pacote BEACON
                beaconPacket = new Basic802154AroundPacket("PAN beacon packet", MAC_LAYER_PACKET);
				// Definde Endereço destino: BROADCAST
                beaconPacket->setDstID(BROADCAST_MAC_ADDRESS);
				// Define o ID da PAN: seu próprio endereço MAC
                beaconPacket->setPANid(SELF_MAC_ADDRESS);
				// Seta o tipo do pacote MAC: MAC_802154_BEACON_PACKET (Definido no enum no arquivo msg)
                beaconPacket->setMac802154AroundPacketType(MAC_802154_BEACON_PACKET);
				// Define o parâmetro Beacon Order do pacote beacon
                beaconPacket->setBeaconOrder(beaconOrder);
				// Define o parâmetro Superframe Order do pacote beacon
                beaconPacket->setSuperframeOrder(superframeOrder);
				// Número de sequencia do quadro beacon, se passar de 255, zera
                if (++macBSN > 255)
                    macBSN = 0;
                // Define o parâmetro macBSN do pacote beacon
				beaconPacket->setBSN(macBSN);
				beaconPacket->setCAPlength(aNumSuperframeSlots);
				
				// Campos de GTS e Tamanho do CAP são setados na camada de decisão, em StaticGTS802154
				prepareBeacon_hub(beaconPacket);
                
                // Campos de Endereços Pendentes - Teremos Comunicação Indireta
                
                //ZERO o buffer DownTXBuffer, pois os nós terão que solicitar novamente
                while(!DownTXBuffer.empty()){
                    DownTXBuffer.pop(); //vou apagando a fila original
                }
                
                
                
                // Definindo o tamanho do quadro beacon:
                //BASE_BEACON_PKT_SIZE é definido utilizando #define no arquivo .h
                beaconPacket->setByteLength(BASE_BEACON_PKT_SIZE + beaconPacket->getGTSlistArraySize() * GTS_SPEC_FIELD_SIZE);
				// Tamanho do CAP a partir do quadro beacon
                CAPlength = beaconPacket->getCAPlength();
				// Definição da Variável fim do CAP
                CAPend = CAPlength * aBaseSlotDuration * (1 << superframeOrder) * symbolLen;
				// Incrementa o contador de beacons enviados
                sentBeacons++;
                
                //Testando - Calculando o tempo para usar na fórmula do Around
                timeBeaconPAN = getClock() + TX_TIME(beaconPacket->getByteLength());
                
                // TRACE: transmitindo o quadro beacon com número de sequencia
				//trace() << "Transmitting [PAN beacon packet] now, BSN = " << macBSN;
				//Seta setMacState para MAC_STATE_CAP
                setMacState(MAC_STATE_CAP_CH);
				// Envia o pacote de beacon para o rádio
                toRadioLayer(beaconPacket);
				//Comando para o rádio para mudar para o modo TX
                toRadioLayer(createRadioCommand(SET_STATE, TX));
                // Seta timer ATTEMPT_TX com tempo definido pelo #define no arquivo .h
				setTimer(ATTEMPT_TX, TX_TIME(beaconPacket->getByteLength()));
				beaconPacket = NULL;    // define para nulo o beaconpacket
                
                //Atualiza o tempo do início do próximo superframe, iniciado logo abaixo
				currentFrameStart = getClock() + phyDelayRx2Tx;
				// Seta o timer para envio de Superframe, num tempo de Intervalos de Beacons
                setTimer(FRAME_START, beaconInterval * symbolLen);
                
                setTimer(SLEEP_START, aNumSuperframeSlots * aBaseSlotDuration * (1 << superframeOrder) * symbolLen);
                
			
            } else {    // Se não é um coordenador PAN, fica esperando por beacon
				// Comando para o rádio para setar o estado RX para receber beacon
                //toRadioLayer(createRadioCommand(SET_STATE, RX));
                // Seta time BEACON_TIMEOUT com tempo guardTime
                //trace() << "PREPARANDO PRO CAP";  // Around - Debug
                
                //setTimer(BEACON_TIMEOUT, guardTime * 3);
			}
			break;
		}
            
        // Se preparar para o CAP - nós recebendo beacons
        // Eu separei o frame_receive do frame_start, pois nós CHs também atuam como nós filhos
        case FRAME_RECEIVE: {
///            trace() << "ENTREI NO FRAME_RECEIVE " << SELF_MAC_ADDRESS;  //around - debug
            
            // Comando para o rádio para setar o estado RX para receber beacon
            toRadioLayer(createRadioCommand(SET_STATE, RX));
            // Seta time BEACON_TIMEOUT com tempo guardTime
            trace() << "PREPARANDO PRO CAP";  // Around - Debug
            
            setTimer(BEACON_TIMEOUT, guardTime * 3);
            break;
        }

        case GTS_START: {
			if (macState == MAC_STATE_SLEEP) {
				toRadioLayer(createRadioCommand(SET_STATE, RX));
			}
			setMacState(MAC_STATE_GTS);
			
			// we delay transmission attempt by the time requred by radio to wake up
			// note that GTS_START timer was scheduled exactly phyDelaySleep2Tx seconds
			// earlier than the actual start time of GTS slot
			setTimer(ATTEMPT_TX, phyDelaySleep2Tx);

			// set a timer to go to sleep after this GTS slot ends
			setTimer(SLEEP_START, phyDelaySleep2Tx + GTSlength);

			// inform the decision layer that GTS has started
			startedGTS_node();
			break;
		}

		// timeout de beacon atingido - indica que beacon foi perdido por esse nó
		case BEACON_TIMEOUT: {
			//incrementa lostBeacon, para testar se perdeu sincronia total com o PAN ou se apenas perdeu um ou outro beacon
            //Padrão define que um nó está fora da rede se perder aMaxLostBeacons beacons
            trace() << "ENTREI NO BEACON TIMEOUT!";
            lostBeacons++;
			//Se perder >= aMaxLostBeacons, perdeu sincronia com PAN
            if (lostBeacons >= aMaxLostBeacons) {
				// Imprime a perca de sincronização
                trace() << "Lost synchronisation with PAN " << associatedPAN;
				// Seta MacState para MAC_STATE_SETUP
                setMacState(MAC_STATE_SETUP);
				associatedPAN = -1;             //associatedPAN volta para o inicial -1
				desyncTimeStart = getClock();   //pega o momento que se desincronizou
				disconnectedFromPAN_node();     //essa função serve para resetar os slots de GTS
				//se tem pacote atual...
                if (currentPacket)
                    //...Chama a função para imprimir a mensagem do argumento
                    clearCurrentPacket("No PAN");
			} else
                // o nó é associado, mas perdeu um beacon e será acordado para o próximo
                if (associatedPAN != -1) {
				    //imprime no trace a perca do beacon
                    trace() << "Missed beacon from PAN " << associatedPAN <<
				    ", will wake up to receive next beacon in " <<
				    beaconInterval * symbolLen - guardTime * 3 << " seconds";
                    //Seta MacState para SLEEP
                    setMacState(MAC_STATE_SLEEP);
                    // Manda comando pro rádio para dormir
                    toRadioLayer(createRadioCommand(SET_STATE, SLEEP));
                    //Seta temporizador FRAME_START
                    //setTimer(FRAME_START, beaconInterval * symbolLen - guardTime * 3); //original
                    setTimer(FRAME_RECEIVE, beaconInterval * symbolLen - guardTime * 3);
                }
			break;
		}
		
		// packet was not received
		case ACK_TIMEOUT: {
			collectPacketHistory("NoAck");
			attemptTransmission("ACK timeout");
			break;
		}

		// Transmissão anterior é resetada, tenta uma nova transmissão
		case ATTEMPT_TX: {
			// pega o tempo do Timer ACK_TIMEOUT
            if(getTimer(ACK_TIMEOUT) != -1)
                break;
			// Função definida abaixo
            attemptTransmission("ATTEMPT_TX timer");
			break;
		}

		// timer to preform Clear Channel Assessment (CCA) 
		case PERFORM_CCA: {
			if (macState == MAC_STATE_GTS || macState == MAC_STATE_SLEEP) break;
			CCA_result CCAcode = radioModule->isChannelClear();
			if (CCAcode == CLEAR) {
				//Channel clear
				if (--CW > 0) {
					setTimer(PERFORM_CCA, aUnitBackoffPeriod * symbolLen);
				} else {
					transmitCurrentPacket();
				}
			} else if (CCAcode == BUSY) {
				//Channel busy
				CW = enableSlottedCSMA ? 2 : 1;
				if (++BE > macMaxBE)
					BE = macMaxBE;
				if (++NB > macMaxCSMABackoffs) {
					collectPacketHistory("CSfail");
					currentPacketRetries--;
					attemptTransmission("Current NB exeeded maxCSMAbackoffs");
				} else {
					performCSMACA();
				}
			} else if (CCAcode == CS_NOT_VALID_YET) {
				//Clear Channel Assesment (CCA) pin is not valid yet
				setTimer(PERFORM_CCA, phyDelayForValidCS);
			} else {	
				//Clear Channel Assesment (CCA) pin is not valid at all (radio is sleeping?)
				trace() << "ERROR: isChannelClear() called when radio is not ready";
				toRadioLayer(createRadioCommand(SET_STATE, RX));
			}
			break;
		}

		case SLEEP_START: {
			// SLEEP_START timer can sometimes be scheduled in the end of a frame
			// i.e. when BEACON_ORDER = FRAME_ORDER, overlapping with the interval 
			// when a node already tries to prepare for beacon reception. Thus 
			// check if BEACON_TIMEOUT timer is set before going to sleep
			if (getTimer(BEACON_TIMEOUT) != -1) break;
            
            //Around - debug
            trace() << "INDO DORMIR!! ";  // Around - Debug
            
			cancelTimer(PERFORM_CCA);
			setMacState(MAC_STATE_SLEEP);
			toRadioLayer(createRadioCommand(SET_STATE, SLEEP));
			break;
		}
		
		case BACK_TO_SETUP: {
			// Este Timer é escalonado para o fim do período CAP quando beacon é recebio, mas o nó não está (ainda) conectado
            // Assim, quando esse timer expirar e o nó não estiver conectado ainda, ele terá que ir de volta para o estágio de SETUP
			if (associatedPAN == -1)       //ou seja, não terminou a conexão à PAN em questão
                setMacState(MAC_STATE_SETUP);   //volta para o estado MAC_STATE_SETUP
            break;
        }
            

            
            
	}
}



//----------------------------------------------------------------------------------------------------------------------------
//
//  FROM RADIO LAYER
//
//----------------------------------------------------------------------------------------------------------------------------



// Função para manusear um quadro MAC recebido da camada mais abaixo (física ou rádio)
void Basic802154Around::fromRadioLayer(cPacket * pkt, double rssi, double lqi){
    //criar um pacote rcvPacket, que irá receber pkt
    Basic802154AroundPacket *rcvPacket = dynamic_cast<Basic802154AroundPacket*>(pkt);
    if (!rcvPacket) {
        return;
    }
    
    //Testa se o DstID é diferente do dele ou BROADCAST_MAC_ADDRESS. Se o endereço destino não é o dele ou não for de Broadcast, a função retorna
    if (rcvPacket->getDstID() != SELF_MAC_ADDRESS &&
        rcvPacket->getDstID() != BROADCAST_MAC_ADDRESS) {
        return;
    }
    
    //Entra no switch, considerando o tipo do Pacote
    switch (rcvPacket->getMac802154AroundPacketType()) {
            
        //Recebeu um pacote de Formação
        case MAC_802154_FORMATION_PACKET: {
            //Coordenadores PAN, cluster-heads e nós já associados ignoram quadros de formação de clusters
            if ((isPANCoordinator) || (isCH) || (associatedPAN != -1))
                break;
            
            double offset = TX_TIME(rcvPacket->getByteLength());    // Função do OMNeT, que filtra o tamanho total do pacote (incluindo GTS)
            currentFrameStart = getClock() - offset;                //O inicio do quadro de formação está no passado
            
///            trace() << "offset " << offset << " currentframestart " << currentFrameStart << " time agora " << getClock();  // Around - Debug
            
            // Setando as variáveis recebidas do pacote
            depth = rcvPacket->getDepth() + 1;                      //pega profundidade no cluster-tree
            formationSeqNum = rcvPacket->getFormBSN();
///            trace() << "Depth " << depth << " e formationSeqNum " << formationSeqNum;  // Around - Debug
                
            // Seta o estado do MAC para MAC_STATE_FORMATION
            setMacState(MAC_STATE_FORMATION);
                
            // Função para transmitir um quadro de associação
            Basic802154AroundPacket *associate = new Basic802154AroundPacket("PAN Associate Request", MAC_LAYER_PACKET);
            associate->setDstID(rcvPacket->getPANid());
            associate->setPANid(rcvPacket->getPANid());
            associate->setMac802154AroundPacketType(MAC_802154_ASSOCIATE_PACKET);
            associate->setSrcID(SELF_MAC_ADDRESS);
            associate->setByteLength(COMMAND_PKT_SIZE);
            
            transmitPacket(associate);
            //attemptTransmission("Association started");
            
            
            //transmitPacket(newAssociationRequest(rcvPacket->getPANid()));
            //attemptTransmission("Formation started");
            //setTimer(CLUSTER_FORMATION, formationTime - guardTime - offset);
            
            //Testando ao enviar pedido de Associacao, ir para o CAP considerando 10s de setup da rede
            //setMacState(MAC_STATE_CAP);
            //setTimer(FRAME_START, 10 - getClock() - guardTime);
            
            //Around: Após enviar quadro de associação, ir para Seleçao de CH
            //Tempo: é o tempo de formação vezes a quantidade de envio de pacotes de formação, menos o offset (quando o pacote foi enviado pelo CH) e o guardTime (começar antes do root).
            //Considero também o envio de vários quadros de formação = formationSeqNum * formationTime
            setTimer(CCH_SELECT, maxFormationFrame * formationTime - offset - guardTime - formationSeqNum * formationTime);
                     
            break;
        }
        
            
        // Recebeu uma confirmação de associação e autorização para construir novo cluster
        case MAC_802154_CCH_PACKET: {
            //Autorização para novo cluster é enviado diretamente para um nó específico
            if(SELF_MAC_ADDRESS != rcvPacket->getDstID()){
///                trace() << "Nao eh meu mas recebi. No " << SELF_MAC_ADDRESS;  // Around - Debug
                break;
            }
            
            //Valores de RSSI e LQI
///            trace() << "RSSI = " << rssi << "; e LQI = " << lqi;  // around - debug
            
            //Define sua associação ao Coordinator/Cluster-Head que enviou a confirmação
            associatedPAN = rcvPacket->getPANid();
            formationSeqNum = 0;
///            trace() << "No " << SELF_MAC_ADDRESS << " Associado ao PAN: " << associatedPAN << " com CH: " << rcvPacket->getNewCH();  // Around - Debug
            if (rcvPacket->getNewCH()) {
                isCH = true;  //Definindo que é CH. Porém, isso só deve acontecer na hora de buscar novos filhos. Se não conseguir, ele não deve ser cluster-head
                position = rcvPacket->getPosition();
///                trace() << "POSITION :" << position;
                
                setTimer(CLUSTER_FORMATION, rcvPacket->getStartTime());  // com um delay com sobra de 0.01
            }
            
            //Se o getPANid for -1, é porque trata-se de uma desalocação. Assim, foi utilizado CSMA.
            // Então é necessário enviar um quadro de ACK para avisar o CH que deixou de ser CH e está tentando desalocar seus nós
            if(rcvPacket->getPANid() == -1){
///                trace() << "MEU CH " << rcvPacket->getSrcID() << " FOI DESALOCADO. MEU NOVO ASSOCIATEDPAN: " << associatedPAN;
                Basic802154AroundPacket *ackPacket = new Basic802154AroundPacket("PAN associate response", MAC_LAYER_PACKET);
                ackPacket->setMac802154AroundPacketType(MAC_802154_ACK_PACKET);
                ackPacket->setSrcID(SELF_MAC_ADDRESS);
                ackPacket->setDstID(rcvPacket->getSrcID());
                ackPacket->setByteLength(ACK_PKT_SIZE);
                
                toRadioLayer(ackPacket);
                toRadioLayer(createRadioCommand(SET_STATE, TX));
                setTimer(ATTEMPT_TX, TX_TIME(ACK_PKT_SIZE));
            }
            
        
            break;
        }
            
            
            
        // Tive que criar esse case, para o caso de nós CH re-confirmando nós que são seus fihos
        // O procedimento de re-confirmação ocorre no collisionDomain
        case MAC_802154_AGAINCCH_PACKET: {
            //Autorização para novo cluster é enviado diretamente para um nó específico
            if(SELF_MAC_ADDRESS != rcvPacket->getDstID()){
                ///                trace() << "Nao eh meu mas recebi. No " << SELF_MAC_ADDRESS;  // Around - Debug
                break;
            }
            
            //Define minha associação ao meu pai que me avisou que eu sou seu filho
            associatedPAN = rcvPacket->getPANid();
            
            //Tenho que re-enviar o pacote para participar do CollisionDomain
            // Cria um pacote
            collisionDomainPacket = new Basic802154AroundPacket("Again Collision Domain Formation", MAC_LAYER_PACKET);
            
            collisionDomainPacket->setMac802154AroundPacketType(MAC_802154_COLLISIONDOMAIN_PACKET);
            collisionDomainPacket->setSrcID(SELF_MAC_ADDRESS);
            collisionDomainPacket->setDstID(BROADCAST_MAC_ADDRESS);
            collisionDomainPacket->setPANid(associatedPAN);
            if((isPANCoordinator) || (isCH)){
                collisionDomainPacket->setIsCH(true);
                if(nchildren < nchildrenMAX)
                    collisionDomainPacket->setAssociationAllow(true);
                else
                    collisionDomainPacket->setAssociationAllow(false);
            }
            else{
                collisionDomainPacket->setIsCH(false);
                collisionDomainPacket->setAssociationAllow(false);
            }
            collisionDomainPacket->setByteLength(CCH_PKT_SIZE);
            toRadioLayer(collisionDomainPacket);
            toRadioLayer(createRadioCommand(SET_STATE, TX));
            setTimer(ATTEMPT_TX, TX_TIME(CCH_PKT_SIZE));
            
            break;
        }
        
        
            
        
        // Recebeu uma confirmação de um CCH que é sim Cluster-Head
        case MAC_802154_CH_RESPONSE_PACKET: {
            //Somente o pai do CCH que enviou é o interessado
            if (SELF_MAC_ADDRESS != rcvPacket->getDstID())
                break;
            
            //Valores de RSSI e LQI
///            trace() << "RSSI = " << rssi << "; e LQI = " << lqi; // around - debug
            
            associatedCH.push_back(rcvPacket->getSrcID());
            
            break;
        }
            
            
            
            
            
        //Recebeu um pacote de BEACON
        case MAC_802154_BEACON_PACKET: {
            //Coordenadores PAN ignoram beacons de outras PANs
            if (isPANCoordinator)
                break;
            // Nós associados a outras PANs ignoram também
            if (associatedPAN != -1 && associatedPAN != rcvPacket->getPANid())
                break;
            //Nodes nao associados ignoram beacons!!!
            if (associatedPAN == -1)
                break;
            
            
            if(recvBeacons == 0){
                //Startando a geração de pacotes
                trace() << "Ajustando set rate " << basePacketRate;
                AroundControlMessage *cmd = new AroundControlMessage("Rate Adjustment packet", MAC_CONTROL_MESSAGE);
                cmd->setAroundControlMessageKind(SET_RATE);
                cmd->setParameter(basePacketRate);
                //Enviando a taxa de geração de pacotes para a aplicação
                toNetworkLayer(cmd);
            }
            
            
            
            //Valores de RSSI e LQI
///            trace() << "RSSI = " << rssi << "; e LQI = " << lqi; // around - debug
            
            // Cancela mensagem de timeout de beacon (se presente)
            cancelTimer(BEACON_TIMEOUT);
            recvBeacons++;
///            trace() << "no " <<SELF_MAC_ADDRESS<< " recebeu beacon!";  // Around - Debug
            //Assim, este nó é conectado a essa PAN (ou irá tentar conectar), atualiza parâmetros do frame
            double offset = TX_TIME(rcvPacket->getByteLength());    // Função do OMNeT, que filtra o tamanho total do pacote (incluindo GTS)
            timeBeacon = getClock() - offset;
/////            trace() << "OFFSET DO BEACON: " << offset;
            
            currentFrameStart = getClock() - offset;                //O inicio do superframe está no passado
            lostBeacons = 0;
         
//            superframeOrder = rcvPacket->getSuperframeOrder();                //pega SuperFrame Order (SO)
//            beaconOrder = rcvPacket->getBeaconOrder();              //pega Beacon Order     (BO)
            
            beaconInterval = aBaseSuperframeDuration * (1 << rcvPacket->getBeaconOrder());  //Cálculo do BI
            recMacBSN = rcvPacket->getBSN();           // número de sequencia do quadro beacon (não usado)
            CAPlength = rcvPacket->getCAPlength();  //Pega tamanho do CAP
            CAPend = CAPlength * aBaseSlotDuration * (1 << rcvPacket->getSuperframeOrder()) * symbolLen;  //Calcula o final do CAP
            GTSstart = 0;       //Campos do GTS: início do CFP
            GTSend = 0;         //Campos do GTS: fim do CFP
            GTSlength = 0;      //Campos do gTS: Tamanho do CFP
            
            //analisar se existe GTS para setar os campos de GTS: GTSstart, GTSend e GTSlength
            for (int i = 0; i < (int)rcvPacket->getGTSlistArraySize(); i++) {
                if (rcvPacket->getGTSlist(i).owner == SELF_MAC_ADDRESS) {
                    GTSstart = (rcvPacket->getGTSlist(i).start - 1) *
                    aBaseSlotDuration * (1 << rcvPacket->getSuperframeOrder()) * symbolLen;
                    GTSend = GTSstart + rcvPacket->getGTSlist(i).length *
                    aBaseSlotDuration * (1 << rcvPacket->getSuperframeOrder()) * symbolLen;
                    GTSlength = GTSend - GTSstart;
///                    trace() << "GTS slot from " << getClock() + GTSstart << " to " << getClock() + GTSend << " length " << GTSlength;
                }
            }
            
            
     
            
            // Seta o estado do MAC para MAC_STATE_CAP
            setMacState(MAC_STATE_CAP);
            
            
            
            
            
            //Caso o currentPacket é vazio, mas TXBuffer tem pacotes, é preciso jogar o pacote da ponta em currentPacket,
            // senão o nó não terá nada para transmitir no attemptTransmission
            if(currentPacket == NULL && TXBuffer.size() != 0){
/////                trace() << "PROBLEMA AQUI!!"; //around - debug
                Basic802154AroundPacket *packet = check_and_cast<Basic802154AroundPacket*>(TXBuffer.front());
                TXBuffer.pop();
                
                //Pego o pacote do buffer e já mando para transmissão
                transmitPacket(packet);
            }

            
            
            //se o nó em questão já está associado a PANid do pacote, ou seja, o nó já está Associado
            if (associatedPAN == rcvPacket->getPANid()) {
                // Se início de seu GTS é diferente do fim do CAP
                if (GTSstart != CAPend)
                    // Então, ele vai dormir após CAP, a menos que os slots GTS comecem logo após
                    setTimer(SLEEP_START, CAPend - offset);  //original
                    //testando dormir antes, considerando o atraso na hora de receber o beacon, ACABA FUNCIONANDO
                    //setTimer(SLEEP_START, CAPend - offset - 0.003);
                // Se inicio de GTS for maior que zero, ou seja, tem slots GTS
                if (GTSstart > 0) {
                    // seta o timer GTS_START phyDelaySleep2Tx segundos antes desde que o radio pode estar dormindo
                    setTimer(GTS_START, GTSstart - phyDelaySleep2Tx - offset);  //original
                    //testando dormir antes, considerando o atraso na hora de receber o beacon
                    //setTimer(GTS_START, GTSstart - phyDelaySleep2Tx - offset - 0.001);
                }
            } else { //nesse caso, o nó recebeu o pacote de beacon e não está associado, ou seja, precisa se associar!!
                // Seta o timer BACK_TO_SETUP
//                setTimer(BACK_TO_SETUP, CAPend - offset);
            }
            
            // Função para reagir ao beacon: se o nó não está conectado a uma PAN, ele transmite um pacote de requisição de associação
//            receiveBeacon_node(rcvPacket);
            //
            attemptTransmission("CAP started");
            // settimer que eu criei, mas ele deve acordar depois de um BI e não de um SD
            setTimer(FRAME_RECEIVE, aBaseSuperframeDuration * (1 << rcvPacket->getBeaconOrder()) * symbolLen - guardTime - offset);
            //setTimer(FRAME_START, aBaseSuperframeDuration * (1 << beaconOrder) * symbolLen - guardTime - offset);   // setTimer original
            
            
            break;
        }
            
        
            
        // Recebe uma requisição de associação
        case MAC_802154_ASSOCIATE_PACKET:{
            
            // Apenas coordenadores PAN podem aceitar requisições de associação
            // Se comunicação MULTIHOP for permitido, torna-se necessário modificar isso
            // Em particular, qualquer nó FFD pode torna-se coordenador e aceitar requisições de associcação
            
            // ERICO: posso fazer o teste com relação a isCH ??
            if ((!isPANCoordinator) && (!isCH))
                break;
            
            // Se o PANid não bate - não faz nada!!
            if (rcvPacket->getPANid() != SELF_MAC_ADDRESS)
                break;
            
            //Valores de RSSI e LQI
///            trace() << "RSSI = " << rssi << "; e LQI = " << lqi; // around - debug
            
            //decisão específica do HUB, definido no .h. Nesse caso, todos os nós requisitando associação, serão associados
            //if (nchildren < 20) {
            if (associationRequest_hub(rcvPacket)) {
///                trace() << "Root " << SELF_MAC_ADDRESS << " recebeu associate packet!";  // Around - Debug
                //escreve no trace que aceita requisicao de associação do nó pedinte!!
/////                trace() << "Accepting association request from " << rcvPacket->getSrcID();
                
                //conta a quantidade de filhos, evitando duplos pedidos de associacao
                if(associatedDevices[rcvPacket->getSrcID()] != true){
///                    trace() << "EU " << SELF_MAC_ADDRESS << " RECEBI a primeira vez e contei como filho o no " << rcvPacket->getSrcID();  //around - debug
                    nchildren++;  //conta a quantidade de filhos
                    
                }
                
                // Atualiza associatedDevices (map <int,bool> com os elementos true associados ao PAN)
                associatedDevices[rcvPacket->getSrcID()] = true;
                associatedDeviceRSSI[rcvPacket->getSrcID()] = rssi;
                
                
                //Around - Se envia está em FORMACAO com envio imediato de ACK ou aceitando nós durante CAP, enviam o ACK de imediato
                //Se estiver em formação sem envio imediato de ACK, não faz o if, ou seja, não envia pacote de ACK
                if ((macState != MAC_STATE_FORMATION) || (nowFormationACK)) {
                    // Cria um pacote de ACK para reply ao nó pedinte da associação
                    Basic802154AroundPacket *ackPacket = new Basic802154AroundPacket("PAN associate response", MAC_LAYER_PACKET);
                    // Seta o id do PAN como o dele do nó
                    ackPacket->setPANid(SELF_MAC_ADDRESS);
                    // Seta o tipo do pacote para MAC_802154_ACK_PACKET, que naturalmente, após ser recebido do radio (fromRadioLayer),
                    // será tratado no case MAC_802154_ACK_PACKET
                    ackPacket->setMac802154AroundPacketType(MAC_802154_ACK_PACKET);
                    // Seta o ID de destino, que será o nó que solicitou a associação
                    ackPacket->setDstID(rcvPacket->getSrcID());
                    // Seta o tamanho do pacote de ACK, que será ACK_PKT_SIZE, definido no #define do .h
                    ackPacket->setByteLength(ACK_PKT_SIZE);
                        
                    // Manda o pacote para o rádio
                    toRadioLayer(ackPacket);
                    // Comando do rádio para ir ao estado TX
                    toRadioLayer(createRadioCommand(SET_STATE, TX));
                    // Seta o time ATTEMPT_TX com o tempo relativo ao tamanho do pacote
                    setTimer(ATTEMPT_TX, TX_TIME(ACK_PKT_SIZE));
                }
                
                
                
            }
            // Não existe uma implementação de um(ns) motivo(s) de não aceitação de associação de um nó
/////            else {
/////                trace() << "Denied association request from " << rcvPacket->getSrcID();
                // Além de não existir uma implmementação para envio de um pacote para negar a requisição
                // além de enviar o nó novamente para um estado de SETUP. Isso, acredito, que possa ser facilmente feito
/////            }
            
            
            break;
        }
            
            // Recebe uma requisição de GTS
        case MAC_802154_GTS_REQUEST_PACKET:{
            
            // Apenas coordenadores PAN podem aceitar requisições de GTS
            if (!isPANCoordinator)
                break;
            
            // Testa se PANid corresponde ao do coordenador em questão, se não for, não faz nada
            if (rcvPacket->getPANid() != SELF_MAC_ADDRESS)
                break;
            
            //Valores de RSSI e LQI
///            trace() << "RSSI = " << rssi << "; e LQI = " << lqi; // around - debug
            
            //informa no trace que recebeu pedido de GTS do nó específico
///            trace() << "Received GTS request from " << rcvPacket->getSrcID();
            
            // Reply com um ACK
            //Cria um pacote de ACK
            Basic802154AroundPacket *ackPacket = new Basic802154AroundPacket("PAN GTS response", MAC_LAYER_PACKET);
            // Seta PANid como o dele mesmo
            ackPacket->setPANid(SELF_MAC_ADDRESS);
            // SEta type do pacote como ACK PACKET
            ackPacket->setMac802154AroundPacketType(MAC_802154_ACK_PACKET);
            // Seta Id destino como o de origem da requisição do GTS
            ackPacket->setDstID(rcvPacket->getSrcID());
            // Seta o tamanho do pacote como ACK_PKT_SIZE, definido com #define no arquivo .h
            ackPacket->setByteLength(ACK_PKT_SIZE);
            // Função gtsRequest_hub toma a decisão da quantidade de GTS par alocar
            ackPacket->setGTSlength(gtsRequest_hub(rcvPacket));
            
            // Envia o pacote ao rádio
            toRadioLayer(ackPacket);
            // Envia comando do rádio para entrar em modo TX
            toRadioLayer(createRadioCommand(SET_STATE, TX));
            // Seta o time ATTEMPT_TX para o tempo do tamanho do pacote ACK
            setTimer(ATTEMPT_TX, TX_TIME(ACK_PKT_SIZE));
            
            break;
        }
            
            // Recebe um quadro ACK, que será manuseado pela função handleAclPacket
        case MAC_802154_ACK_PACKET:{
            // Testa se ele é o endereço destino do pacote ACK. Se não for, descarta o pacote
            if (rcvPacket->getDstID() != SELF_MAC_ADDRESS)
                break;
            // A função handleAckPacket irá manusear o pacote de ACK
            handleAckPacket(rcvPacket);
            break;
        }
            
        
            
        // Caso nenhum, avisa que o quadro não é reconhecido!!
        default:{
            trace() << "WARNING: unknown packet type received [" << rcvPacket->getName() << "]";
        }
    }
}



//----------------------------------------------------------------------------------------------------------------------------
//
//  FROM NETWORK LAYER
//
//----------------------------------------------------------------------------------------------------------------------------



// Pacote recebido da camada superior (Rede)
void Basic802154Around::fromNetworkLayer(cPacket * pkt, int dstMacAddress)
{
    //Criando um novo pacote "macPacket" (pacote de dados), que irá encapsular o pacote da camada de rede
//    Basic802154AroundPacket *macPacket = new Basic802154AroundPacket("802.15.4 MAC data packet", MAC_LAYER_PACKET);
//    //encapsula um pacote de routing pkt em um pacote MAC macPacket
//    //deve ser feito antes de setar qualquer campo do pacote MAC, pois ele "envia" o campo de destino para BROADCAST_MAC_ADDRESS
//    encapsulatePacket(macPacket, pkt);
//    
//    macPacket->setSrcID(SELF_MAC_ADDRESS);
//    
//    //but we are not using short addresses in this model
//    macPacket->setDstID(dstMacAddress);
//    macPacket->setMac802154PacketType(MAC_802154_DATA_PACKET);
//    macPacket->setSeqNum(seqNum++);
//    if (seqNum > 255) seqNum = 0;
//    if (!acceptNewPacket(macPacket)) packetoverflow++;
    
}
    
    
    


//----------------------------------------------------------------------------------------------------------------------------
//
//  FINISH
//
//----------------------------------------------------------------------------------------------------------------------------



// Coleta dos dados para Estatística no CastaliaResults
// declareOutput define o nome da estatística
// collectOutput coleta os dados e joga no declareOutput específico
void Basic802154Around::finishSpecific()
{
    //Around - debug: Imprime se é CH
    if((isCH)||(isPANCoordinator)){
        trace() << "SOU CH " << SELF_MAC_ADDRESS << " COM PROFUNDIDADE " << depth;
    }
    
    
    // Imprimindo no arquivo MAC cada CH com a lista de seus filhos
    map <int,bool>::const_iterator i1;
    if((isCH)||(isPANCoordinator)){
        //for (i1 = associatedDevices.begin(); i1 != associatedDevices.end(); i1++) {
            //Macinfos() << SELF_MAC_ADDRESS << " " << i1->first;
        //}
    }
    

    
    
    
    vector<int>::iterator it1;
    
    //Variável para definir qual é a profunidade máxima de cada simulação
    int depthMAX = 0;
    
    
    
    //Contando o numero de nodes orfãos na rede
    if(isPANCoordinator){
        int contOrphan = 0;
        
        int total = getParentModule()->getParentModule()->getParentModule()->par("numNodes");
        
        
        for (int i = 1; i <= total-1; i++){ // total de nodes, excluindo o proprio PAN
            Basic802154Around *Node = check_and_cast<Basic802154Around*>(getParentModule()->getParentModule()->getParentModule()->getSubmodule("node",i)->getSubmodule("Communication")->getSubmodule("MAC"));
            trace() << "PPP Node " << i << " associated pan = " << Node->getAssociatedPAN();
            
            if(Node->getAssociatedPAN() == -1){ //Node não associado. Conta como órfão!!
                trace() << "ORPHAN: " << i;
                contOrphan++;
            }
        
        }
               
        //Incluindo no CastaliaResults a quantidade de clusters
        declareOutput("Number of Orphan Nodes");
        collectOutput("Number of Orphan Nodes", "", contOrphan);
    
    
    }
    
    
    // Para ser usado no matlab
    trace() << "XX " << SELF_MAC_ADDRESS << " associatedPAN " << associatedPAN;  // Around - Debug
    
    // Saber quantos filhos cada CH tem
    if((isCH)||(isPANCoordinator)){
        trace() << "No: " << SELF_MAC_ADDRESS << " associado a " << associatedPAN << " com " << nchildren << " filhos!";
        
    }
    
    
    
    if (currentPacket)
		cancelAndDelete(currentPacket);
    if (desyncTimeStart >= 0)
		desyncTime += getClock() - desyncTimeStart;
    
    map <string,int>::const_iterator iter;

	declareOutput("Packet breakdown");
	if (packetoverflow > 0)
		collectOutput("Packet breakdown", "Failed, buffer overflow", packetoverflow);
	for (iter = packetBreak.begin(); iter != packetBreak.end(); ++iter) {
		if (iter->first.compare("Success") == 0) {
			collectOutput("Packet breakdown", "Success, first try", iter->second);
		} else if (iter->first.compare("Broadcast") == 0) {
			collectOutput("Packet breakdown", "Broadcast", iter->second);
		} else if (iter->first.find("Success") != string::npos) {
			collectOutput("Packet breakdown", "Success, not first try", iter->second);
		} else if (iter->first.find("NoAck") != string::npos) {
			collectOutput("Packet breakdown", "Failed, no ack", iter->second);
		} else if (iter->first.find("CSfail") != string::npos) {
			collectOutput("Packet breakdown", "Failed, busy channel", iter->second);
		} else if (iter->first.find("NoPAN") != string::npos) {
			collectOutput("Packet breakdown", "Failed, no PAN", iter->second);
        } else if (iter->first.find("Replaced") != string::npos) {                          //incluído para pacotes substituidos
            collectOutput("Packet breakdown", "Failed, Packet was replaced", iter->second); //incluído para pacotes substituidos
		} else {
			trace() << "Unknown packet breakdown category: " <<
				iter->first << " with " << iter->second << " packets";
		}
	}
    
    //Estatísticas para pacotes de dados substituídos ao chegar da camada de rede, por existir outro na fila
    declareOutput("Replaced Data Packets");
    if (replacedPackets > 0)
        collectOutput("Replaced Data Packets", "Replaced", replacedPackets);
    
    
    if(isPANCoordinator)
        trace() << "END SIMULATION!";
    
    
}


// Função de ajuda para mudar o estado do MAC interno e imprimir uma declaração de debug se necessário
void Basic802154Around::setMacState(int newState)
{
	//Se o estado antigo macState for o memso do novo estado, ele apenas retorna e nada imprime
    if (macState == newState){
		//Se quiser imprimir qu enão houve mudança de estado
/////        trace() << "Same Current MAC state: " << stateDescr[macState]; //add ERICO
        return;
    }
	//imprime no trace que mudou de um estado macState (antigo) para um novo estado (newState)
/////    if (printStateTransitions)
/////		trace() << "MAC state changed from " << stateDescr[macState] << " to " << stateDescr[newState];
	macState = newState;
}

Basic802154AroundPacket *Basic802154Around::newConnectionRequest(int PANid) {
	Basic802154AroundPacket *result = new Basic802154AroundPacket("PAN associate request", MAC_LAYER_PACKET);
	result->setDstID(PANid);
	result->setPANid(PANid);
	result->setMac802154AroundPacketType(MAC_802154_ASSOCIATE_PACKET);
	result->setSrcID(SELF_MAC_ADDRESS);
	result->setByteLength(COMMAND_PKT_SIZE);
	return result;
}

Basic802154AroundPacket *Basic802154Around::newGtsRequest(int PANid, int slots) {
	Basic802154AroundPacket *result = new Basic802154AroundPacket("GTS request", MAC_LAYER_PACKET);
	result->setPANid(PANid);
	result->setDstID(PANid);
	result->setMac802154AroundPacketType(MAC_802154_GTS_REQUEST_PACKET);
	result->setSrcID(SELF_MAC_ADDRESS);
	result->setGTSlength(slots);
	result->setByteLength(COMMAND_PKT_SIZE);
	return result;
}



//----------------------------------------------------------------------------------------------------------------------------
//
//  HANDLE ACK PACKETS
//
//----------------------------------------------------------------------------------------------------------------------------



void Basic802154Around::handleAckPacket(Basic802154AroundPacket * rcvPacket)
{
	if (currentPacket == NULL) {
/////		trace() << "WARNING received ACK packet while currentPacket == NULL";
		return;
	}
		
	cancelTimer(ACK_TIMEOUT);

	switch (currentPacket->getMac802154AroundPacketType()) {

		//received an ack while waiting for a response to association request
		case MAC_802154_ASSOCIATE_PACKET: {
            associatedPAN = rcvPacket->getPANid();
			if (desyncTimeStart >= 0) {
				desyncTime += getClock() - desyncTimeStart;
				desyncTimeStart = -1;
			}
/////			trace() << "Associated with PAN:" << associatedPAN;
			
            //Antigo - Se associa e já vai para o CAP
            //setMacState(MAC_STATE_CAP);
			
            
            clearCurrentPacket("Success",true);
			connectedToPAN_node(); //Essa função não faz nada!!
            
            //Around - Depois de se associar, dorme e espera instruções
            //setTimer(SLEEP_START,0); //Cancelado por enquanto
            
            break;
		}

		
        case MAC_802154_CCH_PACKET:{
            
/////            trace() << "NODE FILHO: " << rcvPacket->getSrcID() << " FOI DESALOCADO COM SUCESSO!";
            
            clearCurrentPacket("Success",true);
            
            break;
        }
         
            
		case MAC_802154_GTS_REQUEST_PACKET:{
			assignedGTS_node(rcvPacket->getGTSlength());
			clearCurrentPacket("Success",true);
			break;
		}
            
        

		default:{
/////			trace() << "WARNING: received unexpected ACK to packet [" << currentPacket->getName() << "]";
			break;
		}
	}
}



//----------------------------------------------------------------------------------------------------------------------------
//
//  HANDLE MAC COMMAND
//
//----------------------------------------------------------------------------------------------------------------------------


// Nicolas, esse ponto é bem interessante!! Aqui que você poderá receber as mensagens de controle enviado a partir da camada de redes.
// Então, iremos trabalhar em algumas coisas por aqui

int Basic802154Around::handleControlCommand(cMessage * msg){
    trace() << "RECEBI COMANDO DA CAMADA SUPERIOR!";
    
    AroundControlMessage *cmd = check_and_cast <AroundControlMessage*>(msg);
    
    switch(cmd->getAroundControlMessageKind()) {
            
        default:{
            trace() << "WARNING: unknown control message type received [" << cmd->getName() << "]";
            
        }
    }

    return 0;
}



//----------------------------------------------------------------------------------------------------------------------------
//
//  CSMA-CA ALGORITHM - SEVERAL FUNCTIONS
//
//----------------------------------------------------------------------------------------------------------------------------



/* Finishes the transmission attempt(s) for current packet
 * Records packet history and performs transmission outcome callback
 */
void Basic802154Around::clearCurrentPacket(const char * s, bool success) {
	if (currentPacket == NULL) return;
	if (s) collectPacketHistory(s);
	if (success) currentPacketSuccess = true;
	if (currentPacket->getMac802154AroundPacketType() == MAC_802154_DATA_PACKET) {
		if (currentPacket->getDstID() != BROADCAST_MAC_ADDRESS)
			packetBreak[currentPacketHistory]++;
		else
			packetBreak["Broadcast"]++;
    
	}
	
    //a linha abaixo é a original
    trace() << "Transmission outcome for [" << currentPacket->getName() << "]: " << currentPacketHistory;
    
    
    //TESTANDO ESTATISTICA PARA PACOTES PERDIDOS
    if(currentPacket->getMac802154AroundPacketType() == MAC_802154_DATA_PACKET){
        if(currentPacketHistory.find("Success") == string::npos){
//            collectOutput("PERCA",currentPacket->getSource());
        }
        
        
    }
        
	
	// transmissionOutcome callback below might request another transmission by
	// calling transmitPacket(). Therefore, we save and clear the currentPacket 
	// variable and delete it only _after_ the callback.
	Basic802154AroundPacket *tmpPacket = currentPacket;
	
    
    currentPacket = NULL;
    transmissionOutcome(tmpPacket, currentPacketSuccess, currentPacketHistory);
    cancelAndDelete(tmpPacket);
    
    
}

// This function provides a new packet to be transmitted by the MAC
// It may not be transmitted immediately, but MAC will keep it untill 
// one of the following happens:
// 1) All transmission attempts were exausted (if specified)
// 2) Delay limit was exceeded (if specified)
// 3) Packet can not be delivered, e.g. if PAN connection is lost
// 4) transmitPacket called again, replacing the old packet
void Basic802154Around::transmitPacket(Basic802154AroundPacket *pkt, int retries, bool state, double limit) {
	clearCurrentPacket("Replaced"); //acaba apagando o currentPacket. Assim coloquei o status "Replaced"
/////	trace() << "transmitPacket([" << pkt->getName() << "]," << retries << "," << state << "," << limit << ")";
	currentPacket = pkt;
	currentPacketGtsOnly = state;
	currentPacketHistory = "";
	currentPacketLimit = limit;
	currentPacketSuccess = false;
	if (currentPacket->getDstID() == BROADCAST_MAC_ADDRESS) {
		currentPacketRetries = 1;
		currentPacketResponse = 0;
	} else {
		currentPacketRetries = retries == 0 ? macMaxFrameRetries : retries;
		currentPacketResponse = macAckWaitDuration;
        
        //Around - Se nowACK for true, quadros de associação esperam ACK imediato por um período ACK_TIMEOUT um pouco maior
        if (macState == MAC_STATE_FORMATION) {
            //Tendo ACK de imediato
            if (nowFormationACK) {
                currentPacketResponse = ackWaitFormation;
            } else { // Sem ACK de imediato
                currentPacketResponse = 0;
            }
            
        }
        
	}
    if (getTimer(ATTEMPT_TX) < 0 && getTimer(ACK_TIMEOUT) < 0)
        attemptTransmission("transmitPacket() called");
}


// Esta função irá iniciar uma tentativa de transmissão (ou retransmissão)
void Basic802154Around::attemptTransmission(const char * descr)
{
	// Cancela o timer ATTEMPT_TX
    cancelTimer(ATTEMPT_TX);
	
    // Se o Estado MAC tiver como SLEEP ou SETUP, a função retorna
    if (macState == MAC_STATE_SLEEP || macState == MAC_STATE_SETUP)
        return;
	// Gravado no trace a transmissão e sua descrição, passado para quem chamou a função
/////    trace() << "Attempt transmission, description: " << descr;
	
	// Se um pacote já enfileirado para transmissão - checa retries e atraso disponíveis
	if (currentPacket && (currentPacketRetries == 0 || (currentPacketLimit > 0 && (simTime() - currentPacket->getCreationTime()) > currentPacketLimit))) {
		clearCurrentPacket();
		return;
	}
	
	if (currentPacket) {
		//ERICO
        if (macState == MAC_STATE_GTS) {
/////			trace() << "Transmitting [" << currentPacket->getName() << "] in GTS";
			transmitCurrentPacket();
		} else
            if (macState == MAC_STATE_CAP && currentPacketGtsOnly == false) {
/////                trace() << "Transmitting [" << currentPacket->getName() << "] in CAP, starting CSMA_CA";
                NB = 0;
                CW = enableSlottedCSMA ? 2 : 1;
                BE = macBattLifeExt ? (macMinBE < 2 ? macMinBE : 2) : macMinBE;
                performCSMACA();
            } else
                if(macState == MAC_STATE_FORMATION){
/////                    trace() << "Transmitting [" << currentPacket->getName() << "] in CAP, starting CSMA_CA";
                    NB = 0;
                    CW = enableSlottedCSMA ? 2 : 1;
                    BE = macBattLifeExt ? (macMinBE < 2 ? macMinBE : 2) : macMinBE;
                    performCSMACA();
                } else
                    if(macState == MAC_STATE_CAP_CH){
                        //Código inicial
  
            
                } /////else
                    /////trace() << "Skipping transmission attempt in CAP due to GTSonly flag";
            
	}
/////    else {
/////		trace() << "Nothing to transmit";
/////	}
}

// continue CSMA-CA algorithm
void Basic802154Around::performCSMACA()
{
	//generate a random delay, multiply it by backoff period length
	int rnd = genk_intrand(1, (1 << BE) - 1) + 1;
	simtime_t CCAtime = rnd * (aUnitBackoffPeriod * symbolLen);

	//if using slotted CSMA - need to locate backoff period boundary
	if (enableSlottedCSMA) {
		simtime_t backoffBoundary = (ceil((getClock() - currentFrameStart) / (aUnitBackoffPeriod * symbolLen)) -
		     (getClock() - currentFrameStart) / (aUnitBackoffPeriod * symbolLen)) * (aUnitBackoffPeriod * symbolLen);
		CCAtime += backoffBoundary;
	}

/////	trace() << "CSMA/CA random backoff value: " << rnd << ", in " << CCAtime << " seconds";

	//set a timer to perform carrier sense after calculated time
	setTimer(PERFORM_CCA, CCAtime);
}

/* Transmit a packet by sending it to the radio */
void Basic802154Around::transmitCurrentPacket()
{
	if (currentPacket == NULL) {
/////		trace() << "WARNING: transmitCurrentPacket() called while currentPacket == NULL";
		return;
	}
	
	//check if transmission is allowed given current time and tx time
	simtime_t txTime = TX_TIME(currentPacket->getByteLength()) + currentPacketResponse;
	simtime_t txEndTime = getClock() + txTime;
	int allowTx = 1;
	
	if (macState == MAC_STATE_CAP) {	//currently in CAP
    //if (macState == MAC_STATE_CAP || macState == MAC_STATE_CAP_CH_SEND) {	//currently in CAP (member nodes and Cluster-head)
		if (currentFrameStart + CAPend < txEndTime && CAPend != GTSstart)
			//transmission will not fit in CAP 
			allowTx = 0;
	} else if (macState == MAC_STATE_GTS) {	//currently in GTS
		if (currentFrameStart + GTSend < txEndTime)
			//transmission will not fit in GTS
			allowTx = 0;
	}
	
	if (allowTx) {
		if (currentPacket->getMac802154AroundPacketType() == MAC_802154_DATA_PACKET) {
			if (macState == MAC_STATE_CAP) collectOutput("pkt TX state breakdown", "Contention");
            else collectOutput("pkt TX state breakdown", "Contention-free");
                
		}
		//decrement retry counter, set transmission end timer and modify mac and radio states.
		currentPacketRetries--;
		//trace() << "Transmitting [" << currentPacket->getName() << "] now, remaining attempts " << currentPacketRetries;
		setTimer(currentPacketResponse > 0 ? ACK_TIMEOUT : ATTEMPT_TX, txTime);
        
        toRadioLayer(currentPacket->dup());
		toRadioLayer(createRadioCommand(SET_STATE, TX));
        
	} else {
		//transmission not allowed
		trace() << "txTime " << txTime << " CAP:" << (currentFrameStart + CAPend - getClock()) << 
				" GTS:" << (currentFrameStart + GTSend - getClock());
		trace() << "Transmission of [" << currentPacket->getName() << "] stopped, not enough time";
	}
}

// String s represents an outcome of most recent transmission attempt for 
// current packet, it is saved (appended) to the final packet history
void Basic802154Around::collectPacketHistory(const char *s)
{
	if (!currentPacket) {
/////		trace() << "WARNING: collectPacketState called while currentPacket==NULL, string:"<<s;
		return;
	}
	if (currentPacketHistory.size()) {
		currentPacketHistory.append(",");
		currentPacketHistory.append(s);
	} else {
		currentPacketHistory = s;
	}
}



//----------------------------------------------------------------------------------------------------------------------------
//
//  DECISION LAYER FUNCTIONS
//
//----------------------------------------------------------------------------------------------------------------------------



// A function to accept new packet from the Network layer
// ACTION: 	check if packet can be transmitted immediately
//			otherwise accept only if there is room in the buffer
bool Basic802154Around::acceptNewPacket(Basic802154AroundPacket *newPacket)
{
	if (getAssociatedPAN() != -1 && getCurrentPacket() == NULL) {
		transmitPacket(newPacket);
		return true;
	}
	return bufferPacket(newPacket);
}

// Função para reagir a recepção de um beacon
// AÇÃO: Se não associado a um PAN, cria e transmite uma requisição de conexão
void Basic802154Around::receiveBeacon_node(Basic802154AroundPacket *beacon)
{
	// Se associatedPAN do nó é -1, é porque ele não está associado...
    if (getAssociatedPAN() == -1)
		// Transmite um pacote de requisção de associação, endereçado ao ID do PAN
        transmitPacket(newConnectionRequest(beacon->getPANid()));
}

// A function to react to packet transmission callback
// ACTION: Simply transmit next packet from the buffer if associated to PAN
void Basic802154Around::transmissionOutcome(Basic802154AroundPacket *pkt, bool success, string history)
{
	//Código original abaixo
    if (getAssociatedPAN() != -1 && TXBuffer.size()) {
		Basic802154AroundPacket *packet = check_and_cast<Basic802154AroundPacket*>(TXBuffer.front());
		TXBuffer.pop();
		transmitPacket(packet);
	}
    
    
}

//Redefinindo a função de bufferização a fim de alterar o pacote de controle do MAC
int Basic802154Around::bufferPacket(cPacket * rcvFrame)
{
    if ((int)TXBuffer.size() >= macBufferSize) {
        cancelAndDelete(rcvFrame);
        // send a control message to the upper layer
        AroundControlMessage *fullBuffMsg = new AroundControlMessage("MAC buffer full", MAC_CONTROL_MESSAGE);
        fullBuffMsg->setAroundControlMessageKind(BUFFER_FULL);
        
        //MacControlMessage *fullBuffMsg = new MacControlMessage("MAC buffer full", MAC_CONTROL_MESSAGE);
        //fullBuffMsg->setMacControlMessageKind(MAC_BUFFER_FULL);
        send(fullBuffMsg, "toNetworkModule");
        return 0;
    } else {
        // A linha abaixo é para usar buffer sem prioridades
        TXBuffer.push(rcvFrame);
        
        
        return 1;
    }
}



//----------------------------------------------------------------------------------------------------------------------------
//
//  AROUND ALGORITHM FUNCTIONS
//
//----------------------------------------------------------------------------------------------------------------------------



Basic802154AroundPacket *Basic802154Around::newAssociationRequest(int PANid) {
    Basic802154AroundPacket *result = new Basic802154AroundPacket("PAN associate request", MAC_LAYER_PACKET);
    result->setDstID(PANid);
    result->setPANid(PANid);
    result->setMac802154AroundPacketType(MAC_802154_ASSOCIATE_PACKET);
    result->setSrcID(SELF_MAC_ADDRESS);
    result->setByteLength(COMMAND_PKT_SIZE);
    return result;
}




// Função de Seleção de CCH, sem ter base em localização


void Basic802154Around::selectCCH(){
    
    map <int,bool>::const_iterator iter;
    double tch = formationTime * maxFormationFrame; //tempo que leva para formar um cluster
    double tcch = tch + 0.12; //tempo de formação de cluster + uma sobra para troca de mensagens
    double startTime1, startTime2, startTime3, startTime4; //startime para cada nó CCH
    int position1, position2, position3, position4; //para calculo da posicao na largura dos nós CCHs
    //testando algoritmo de seleção de CCH considerando os quadrantes de formação
    int q1,q2,q3,q4;
    double baseRSSI1, baseRSSI2, baseRSSI3, baseRSSI4;
    bool hasCCH = false;  //flag para definir se tem ou não CCH
    baseDepth = par("baseDepth"); //profundidade no qual garanto formação de cluster escalonado no tempo. A partir disso, a formação ocorre em paralelo
    maxCCH = par("maxCCH"); //quantidade máxima de CCHs
    int i = 0; //variavel de controle da quantidade máxima de CCHs
    int j = 0; //variavel de controle para definição dos tempos de formação dos CCHs
    vector <int> cchs;
    //vector <int>::const_iterator viter;
    vector <int>::iterator viter;
    //vector <int>::const_iterator base;
    vector <int>::iterator base;
    
///    trace() << "QUANTIDADE DE DEVICES de " << SELF_MAC_ADDRESS << " eh: " << associatedDevices.size();  // Around - debug
    
    
    
    // O CH define da sua lista de nós associados, quem será os candidatos a CHs
    // Nesse ponto, podemos implementar vários critérios de seleção
    // Abaixo, por exemplo, a seleção é randomica, mas considerando o RSSI, para escolher um CCH mais distante possível do CH em questão, a fim de evitar que os clusters fiquem muito sobrepostos!
    
    // Depois, podemos sentar com o Montez e definir uma política interessante de formação da Cluster-tree
    
    for (iter = associatedDevices.begin(); iter != associatedDevices.end(); iter++) {
        if(i < maxCCH){
            cchs.push_back(iter->first);
            hasCCH = true; //marca que tem CCH
            i++;
        }
        else{
            // procura nos filhos, qual tem menor RSSI
            base = cchs.begin();
            for(viter = cchs.begin(); viter != cchs.end(); viter++){
                if(associatedDeviceRSSI[*viter] < associatedDeviceRSSI[*base]){
                    base = viter;
                }
            }
            // define se o nó em questão tem RSSI menor e se entra na lista dos CCHS e em qual lugar
            if(associatedDeviceRSSI[iter->first] < associatedDeviceRSSI[*base]){
                cchs.erase(base);
                cchs.push_back(iter->first);
            }
            
        }
        
        //Around - Debug - imprimindo o vetor de CCHS para verificações
        //for(viter = cchs.begin(); viter != cchs.end(); viter++){
        //    trace() << iter->first << " " << *viter;
        //}
    }
    
    
    
    // Desaloco CHs com uma quantidade mínima de filhos, a fim de evitar clusters com pouquíssimos nós.
    //Se Nó tiver menos de nchildrenMIN filhos, não deixo ser CH
    if(associatedDevices.size() < nchildrenMIN){
///        trace() << "DESALOCANDO POR POUCO NODES: " << SELF_MAC_ADDRESS << ". QUANT FILHOS: " << associatedDevices.size(); //around - debug
        isCH = false;
        hasCCH = false;
    }

    
    //Criando a estrutura de sequencia de cluster
    // Para não incluir o PAN, basta colocar uma condição && (!PANCoordinator)
    if(!hasCCH){
        //Não tendo CCH, deixa de ser CH
        ///        trace() << "DESALOCANDO POR NAO TER CCH: " << SELF_MAC_ADDRESS; //around - debug
        isCH = false;
    }
    
    
    // Impressao dos CCHs escolhidos
    for(viter = cchs.begin(); viter != cchs.end(); viter++){
        trace() << "CCH Escolhido: " << *viter;
    }
    
    
    //Enviar os ACKs para formação
    for (iter = associatedDevices.begin() ; iter != associatedDevices.end(); iter++) {
        if (iter->second == true) {
            
///            trace() << "Lista Devices a enviar ACK: " << iter->first;  // Around - Debug
            // Cria um pacote de ACK para reply aos nós pelo qual recebeu pedido de associação
            formationAckPacket = new Basic802154AroundPacket("PAN Associate Response", MAC_LAYER_PACKET);
            // Seta o id do PAN como o dele do nó
            formationAckPacket->setPANid(SELF_MAC_ADDRESS);
            // Seta o tipo do pacote para MAC_802154_ACK_PACKET, que naturalmente, após ser recebido do radio (fromRadioLayer),
            // será tratado no case MAC_802154_ACK_PACKET
            formationAckPacket->setMac802154AroundPacketType(MAC_802154_CCH_PACKET);
            // Seta o ID de destino, que será o nó que solicitou a associação
            formationAckPacket->setDstID(iter->first);
            
            
            //Around - Procura se o dispositivo filho em questão foi escolhido como CCH
            bool isCCH = false;
            for(viter = cchs.begin(); viter != cchs.end(); viter++){
                if(iter->first == *viter)
                    isCCH = true;
            }
            
            if(isCCH){
                formationAckPacket->setNewCH(true);
                if(isPANCoordinator){
                    formationAckPacket->setStartTime(tcch + j*tcch);
                    formationAckPacket->setPosition(j);
                }
                else
                    if(depth < baseDepth){
                        // Original
                        //formationAckPacket->setStartTime( (pow(3,depth)+pow(3,depth-1) + 2*position - 1)*tcch + j*tcch);
                        
                        // Nao tinha dado certo tudo alinhado, pois alguns CCHs não recebiam a autorização de formação
                        // Acrescentei entre os níveis mais um TCCH e, pelos testes iniciais, deu certo
                        // Formula: primeira parte é o pulo de nível; o j corresponde aos filhos (1,2 e 3); tcch final corresponde
                        // a um delay de um período de formação de um nível para o outro.
                        formationAckPacket->setStartTime( (pow(3,depth) + 2*position - 1)*tcch + j*tcch + tcch);
                        formationAckPacket->setPosition(3*position + j);
///                        trace() << "STARTTIME " << SELF_MAC_ADDRESS << " -> " << iter->first << ": " << (pow(3,depth) + 2*position - 1) + j + 1 << " TCCH e POSITION " << 3*position + j;  //Around - Debug
                    }
                    else
                        if (depth == baseDepth){
                            //Original
                            //formationAckPacket->setStartTime((pow(3,depth)+pow(3,depth-1)-1)*tcch + j*tcch);
                            // Com a modificação a fim de consertar os tempos de formação
                            formationAckPacket->setStartTime( (pow(3,depth) - 1 - position)*tcch + j*tcch + tcch );
                            formationAckPacket->setPosition(j);
///                            trace() << "STARTTIME " << SELF_MAC_ADDRESS << " -> " << iter->first << ": " << (pow(3,depth) - 1 - position) + j + 1  << " TCCH e POSITION " << j;  //Around - Debug
                        }
                        else{
                            formationAckPacket->setStartTime((2-position)*tcch + j*tcch + tcch);
                            formationAckPacket->setPosition(j);
//       /                     trace() << "STARTTIME " << SELF_MAC_ADDRESS << " -> " << iter->first << ": " << (2-position) + j + 1 << " TCCH e POSITION " << j;  //Around - Debug
                        }
                
                j++;
            
            }
            else{
                //Aqui, o nó em questão não terá nenhum filho CCH, assim, deve-se tomar algumas decisões:
                // 1- Ele deixa de ser CH e desassocia ele e os possíveis filhos que conseguiu??
                // 2- Ele deixa de ser CH e desassocia apenas os possíveis filhos que conseguiu??
                // 3- Ele continua como CH com seus filhos?
                // Minha tendência no momento: opção 2
                // Como fazer cada coisa:
                // - Desassociar ele: seu associatedPAN = -1;
                // - Desassociar seus filhos: enviar associatedPAN = -1 pros filhos
                // - Continuar como CH: não fazer nada
                
                // Opção 2
                //isCH = false;  // Deixa de ser CH
               
                formationAckPacket->setNewCH(false);
            }
            
            // Seta o tamanho do pacote de Formation ACK, que será ACK_CCH_SIZE, definido no #define do .h
            formationAckPacket->setByteLength(CCH_PKT_SIZE);
            
            
            if(hasCCH){
                if(nowFormationACK){
                    if (formationAckPacket->getNewCH() == true) {
///                        trace() << "Autorizado a formar cluster " << iter->first;  // Around - Debug
                        toRadioLayer(formationAckPacket);
                        toRadioLayer(createRadioCommand(SET_STATE, TX));
                        // AssociatedCH não ta servindo para nada, pois se eu incluo um nó como CH e, depois,
                        // ele não agrega nenhum novo CH, ele deixa de ser CH e essa lista do "pai dele" passa
                        // a ficar desatualizada, ou seja, considera ele CH e ele já não é.
                        //associatedCH.push_back(iter->first);
                    }
                    
                } else {
                    //trace() << "ACK de formacao para " << iter->first << " com CH: " << formationAckPacket->getNewCH() << " com StartTime: " << formationAckPacket->getStartTime();  // Around - Debug
///                    trace() << "No " << iter->first << " associated " << SELF_MAC_ADDRESS;  // Around - Debug
                    // Manda o pacote para o rádio
                    toRadioLayer(formationAckPacket);
                    // Comando do rádio para ir ao estado TX
                    toRadioLayer(createRadioCommand(SET_STATE, TX));
                    
                }
                // Seta o time ATTEMPT_TX com o tempo relativo ao tamanho do pacote
                setTimer(ATTEMPT_TX, TX_TIME(CCH_PKT_SIZE));
            }
            else{
                formationAckPacket->setPANid(-1);
                formationAckPacket->setSrcID(SELF_MAC_ADDRESS);
                formationAckPacket->setNewCH(false);
                formationAckPacket->setByteLength(CCH_PKT_SIZE+2);
//                toRadioLayer(formationAckPacket);
//                toRadioLayer(createRadioCommand(SET_STATE, TX));
                acceptNewPacket(formationAckPacket);
            }
            
            
        }  //fim do if
    }  //fim do for
    
    
}


bool Basic802154Around::DuplicatedPacket(cPacket * pkt){
    //extract source address and sequence number from the packet
    Basic802154AroundPacket *macPkt = check_and_cast <Basic802154AroundPacket*>(pkt);
    int src = macPkt->getSource();
    int dst = macPkt->getDestination();
    unsigned int sn = macPkt->getSeqNum();
    pair<int,int> temp = make_pair(src,dst);
    
/////    trace() << "Pacote Atual src-dst: " << src << "-" << dst << " numSeq: " << sn; //around - debug
    
    //if(find(AroundPktHistory.begin(), AroundPktHistory.end(), make_pair(src,dst)) == AroundPktHistory.end() ){
    if(AroundPktHistory.find(make_pair(src,dst)) == AroundPktHistory.end() ){
        trace() << "Nao encontrei esse par src-dst: " << src << "-" << dst;
        AroundPktHistory[make_pair(src,dst)] = sn;
        return false;
    } else {
/////        trace() << "Historico do par src-dst: " << src << "-" << dst << " com numSeq atual de " << AroundPktHistory[make_pair(src,dst)]; //around
        if(sn <= AroundPktHistory[make_pair(src,dst)]){
/////            trace() << "PACOTE DUPLICADO!";
            return true;
        } else {
/////            trace() << "PACOTE NAO DUPLICADO!";
            AroundPktHistory[make_pair(src,dst)] = sn;
            return false;
        }
    }
    
}




//Nova função para definir os parâmetros da formação da rede
int Basic802154Around::associationRequest_hub(Basic802154AroundPacket *) {
    maxChildren = par("maxChildren"); //quantidade máxima de CCHs
    if(nchildren < maxChildren) return 1;
    else return 0;
}

